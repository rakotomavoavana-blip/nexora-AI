import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  FlatList,
  Modal,
  SafeAreaView,
  Platform,
  Dimensions,
  KeyboardAvoidingView,
  ActivityIndicator,
  Switch,
  Pressable,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import Ionicons from '@expo/vector-icons/Ionicons';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

// ================= COLORS =================
const COLORS = {
  navy: '#0F1229',
  navy2: '#171A3A',
  navy3: '#1E2342',
  navyLight: '#282D5C',
  violet: '#7C3AED',
  violetLight: '#8B5CF6',
  violetBright: '#A78BFA',
  violetSoft: '#EDE9FE',
  violetDark: '#5B21B6',
  white: '#FFFFFF',
  bg: '#F8F9FF',
  bg2: '#F1F5FF',
  card: '#FFFFFF',
  border: '#E8E9F1',
  text: '#111827',
  text2: '#4B5563',
  text3: '#9CA3AF',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  blue: '#3B82F6',
};

// ================= TYPES =================
type PlanType = 'starter' | 'pro' | 'business';
type ContactStatus = 'prospect' | 'client' | 'archive' | 'nouveau';
type DevisStatus = 'brouillon' | 'envoye' | 'accepte' | 'refuse' | 'expire';
type ConversationStatus = 'non_lu' | 'lu' | 'en_attente' | 'archive';

interface BusinessConfig {
  id: string;
  nom: string;
  secteur: string;
  services: { nom: string; prix: number; duree: string }[];
  tarifs: string;
  horaires: string;
  telephone: string;
  email: string;
  adresse: string;
  ton: 'professionnel' | 'amical' | 'formel' | 'detendu';
  regles: string;
  siteWeb?: string;
}

interface CRMContact {
  id: string;
  nom: string;
  prenom: string;
  entreprise?: string;
  email: string;
  telephone: string;
  status: ContactStatus;
  notes: string;
  createdAt: string;
  historique: string[];
  source: string;
}

interface DevisLigne {
  id: string;
  description: string;
  quantite: number;
  prixUnitaire: number;
}

interface Devis {
  id: string;
  numero: string;
  contactId: string;
  contactNom: string;
  lignes: DevisLigne[];
  tva: number;
  statut: DevisStatus;
  createdAt: string;
  validite: string;
  notes: string;
}

interface ConversationMsg {
  id: string;
  role: 'user' | 'assistant' | 'client';
  content: string;
  timestamp: string;
}

interface Conversation {
  id: string;
  contactId: string;
  contactNom: string;
  preview: string;
  status: ConversationStatus;
  messages: ConversationMsg[];
  updatedAt: string;
  assignee?: string;
  tags: string[];
}

interface Appointment {
  id: string;
  titre: string;
  contactNom: string;
  date: string;
  heure: string;
  duree: number;
  statut: 'confirme' | 'en_attente' | 'annule';
  notes: string;
}

interface Automation {
  id: string;
  nom: string;
  description: string;
  declencheur: string;
  action: string;
  actif: boolean;
  executions: number;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  type?: 'text' | 'devis' | 'resume';
}

type ScreenName =
  | 'landing'
  | 'features'
  | 'pricing'
  | 'faq'
  | 'login'
  | 'register'
  | 'cgv'
  | 'dashboard'
  | 'assistant'
  | 'config'
  | 'crm'
  | 'devis'
  | 'conversations'
  | 'appointments'
  | 'automations'
  | 'stats'
  | 'subscription'
  | 'admin'
  | 'onboarding';

// ================= MOCK DATA =================
const INITIAL_BUSINESS: BusinessConfig = {
  id: 'biz_1',
  nom: 'Atelier Lumière',
  secteur: 'Coiffeur',
  services: [
    { nom: 'Coupe Homme', prix: 25, duree: '30min' },
    { nom: 'Coupe Femme + Brushing', prix: 55, duree: '60min' },
    { nom: 'Coloration complète', prix: 85, duree: '120min' },
  ],
  tarifs: 'Coupe à partir de 25€, formules complètes sur devis',
  horaires: 'Mar-Sam 9h-19h, fermé dimanche et lundi',
  telephone: '01 23 45 67 89',
  email: 'contact@atelier-lumiere.fr',
  adresse: '12 Rue de la Paix, 75002 Paris',
  ton: 'amical',
  regles: 'Toujours vouvoyer, proposer un créneau sous 48h, ne jamais donner de diagnostic médical.',
  siteWeb: 'www.atelier-lumiere.fr',
};

const MOCK_CONTACTS: CRMContact[] = [
  {
    id: '1',
    nom: 'Dubois',
    prenom: 'Marie',
    entreprise: '',
    email: 'marie.dubois@gmail.com',
    telephone: '06 12 34 56 78',
    status: 'prospect',
    notes: 'Intéressée par balayage + coupe. Budget ~120€',
    createdAt: '2026-10-20',
    historique: ['Premier contact le 20/10', 'Demande devis coloration'],
    source: 'Instagram',
  },
  {
    id: '2',
    nom: 'Martin',
    prenom: 'Thomas',
    entreprise: 'Garage Martin SARL',
    email: 't.martin@garage-martin.fr',
    telephone: '06 98 76 54 32',
    status: 'client',
    notes: 'Client fidèle, vient toutes les 3 semaines',
    createdAt: '2026-09-12',
    historique: ['Client depuis 2024', 'Prestation coupe homme'],
    source: 'Bouche-à-oreille',
  },
  {
    id: '3',
    nom: 'Leroy',
    prenom: 'Sophie',
    entreprise: '',
    email: 'sophie.leroy@outlook.fr',
    telephone: '07 11 22 33 44',
    status: 'nouveau',
    notes: "Demande pour mariage - 5 personnes le 15 novembre",
    createdAt: '2026-10-24',
    historique: ['Demande groupe mariage'],
    source: 'Google',
  },
];

const MOCK_DEVIS: Devis[] = [
  {
    id: 'd1',
    numero: 'DEV-2026-042',
    contactId: '1',
    contactNom: 'Marie Dubois',
    lignes: [
      { id: 'l1', description: 'Coloration complète + patine', quantite: 1, prixUnitaire: 85 },
      { id: 'l2', description: 'Coupe + Brushing inclus', quantite: 1, prixUnitaire: 0 },
      { id: 'l3', description: 'Soin profond kératine', quantite: 1, prixUnitaire: 25 },
    ],
    tva: 20,
    statut: 'envoye',
    createdAt: '2026-10-22',
    validite: '2026-11-22',
    notes: 'Valable 30 jours. Produits L’Oréal inclus.',
  },
  {
    id: 'd2',
    numero: 'DEV-2026-043',
    contactId: '3',
    contactNom: 'Sophie Leroy',
    lignes: [
      { id: 'l1', description: 'Forfait mariée (essai + jour J)', quantite: 1, prixUnitaire: 250 },
      { id: 'l2', description: 'Invitée coiffure (x4)', quantite: 4, prixUnitaire: 65 },
    ],
    tva: 20,
    statut: 'brouillon',
    createdAt: '2026-10-24',
    validite: '2026-11-24',
    notes: 'Déplacement inclus Paris intra-muros.',
  },
];

const MOCK_CONVERSATIONS: Conversation[] = [
  {
    id: 'c1',
    contactId: '1',
    contactNom: 'Marie Dubois',
    preview: 'Bonjour, je voudrais prendre RDV pour une coloration...',
    status: 'non_lu',
    updatedAt: '2026-10-24T14:30:00',
    tags: ['Devis demandé', 'Urgent'],
    messages: [
      { id: 'm1', role: 'client', content: 'Bonjour, je voudrais prendre RDV pour une coloration complète la semaine prochaine, vous avez des dispos ?', timestamp: '2026-10-24T14:30:00' },
    ],
  },
  {
    id: 'c2',
    contactId: '2',
    contactNom: 'Thomas Martin',
    preview: 'Merci pour la coupe de ce matin, parfait comme d’habitude !',
    status: 'lu',
    updatedAt: '2026-10-23T17:15:00',
    tags: ['Fidèle'],
    messages: [
      { id: 'm1', role: 'client', content: 'Merci pour la coupe de ce matin, parfait comme d’habitude !', timestamp: '2026-10-23T17:15:00' },
    ],
  },
  {
    id: 'c3',
    contactId: '3',
    contactNom: 'Sophie Leroy',
    preview: 'Bonjour, c’est pour un groupe de 5 personnes pour un mariage...',
    status: 'en_attente',
    updatedAt: '2026-10-24T09:12:00',
    tags: ['Groupe', 'Mariage', 'Devis'],
    messages: [
      { id: 'm1', role: 'client', content: 'Bonjour, c’est pour un groupe de 5 personnes pour un mariage le 15 novembre. Pouvez-vous faire un devis ?', timestamp: '2026-10-24T09:12:00' },
    ],
  },
];

const MOCK_APPOINTMENTS: Appointment[] = [
  { id: 'a1', titre: 'Coupe Homme - Thomas M.', contactNom: 'Thomas Martin', date: '2026-10-25', heure: '10:00', duree: 30, statut: 'confirme', notes: 'Coupe habituelle' },
  { id: 'a2', titre: 'Coloration - Marie D.', contactNom: 'Marie Dubois', date: '2026-10-25', heure: '14:00', duree: 120, statut: 'en_attente', notes: 'Devis DEV-2026-042' },
  { id: 'a3', titre: 'Essai Mariée - Sophie L.', contactNom: 'Sophie Leroy', date: '2026-10-26', heure: '11:00', duree: 90, statut: 'confirme', notes: 'Prévoir dossier inspiration' },
  { id: 'a4', titre: 'Coupe Femme - Julie P.', contactNom: 'Julie Petit', date: '2026-10-27', heure: '15:30', duree: 60, statut: 'confirme', notes: '' },
];

const MOCK_AUTOMATIONS: Automation[] = [
  { id: 'auto1', nom: 'Relance devis J+3', description: 'Relance automatique si devis non ouvert après 3 jours', declencheur: 'Devis non lu', action: 'Email + SMS relance', actif: true, executions: 24 },
  { id: 'auto2', nom: 'Rappel RDV J-1', description: 'Rappel de rendez-vous la veille à 18h', declencheur: 'RDV demain', action: 'SMS + Email rappel', actif: true, executions: 156 },
  { id: 'auto3', nom: 'Merci après RDV', description: 'Message de remerciement 2h après le RDV', declencheur: 'RDV terminé', action: 'Demande avis Google', actif: true, executions: 142 },
  { id: 'auto4', nom: 'Prospect inactif', description: 'Relance prospect sans nouvelle après 7 jours', declencheur: 'Inactivité 7j', action: 'Message personnalisé IA', actif: false, executions: 18 },
];

// ================= MAIN APP =================
export default function App() {
  const [fontsLoaded] = useFonts({ ...Ionicons.font });
  const [currentScreen, setCurrentScreen] = useState<ScreenName>('landing');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [onboardingDone, setOnboardingDone] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  // Business & User State
  const [userEmail, setUserEmail] = useState('demo@nexora.ai');
  const [business, setBusiness] = useState<BusinessConfig>(INITIAL_BUSINESS);
  const [plan, setPlan] = useState<PlanType>('pro');
  const [planPrices, setPlanPrices] = useState({ starter: 19, pro: 49, business: 99 });
  const [editingPrices, setEditingPrices] = useState(false);

  // Feature States
  const [contacts, setContacts] = useState<CRMContact[]>(MOCK_CONTACTS);
  const [devis, setDevis] = useState<Devis[]>(MOCK_DEVIS);
  const [conversations, setConversations] = useState<Conversation[]>(MOCK_CONVERSATIONS);
  const [appointments, setAppointments] = useState<Appointment[]>(MOCK_APPOINTMENTS);
  const [automations, setAutomations] = useState<Automation[]>(MOCK_AUTOMATIONS);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: `Bonjour ! Je suis Nexora, votre assistant IA configuré pour **${INITIAL_BUSINESS.nom}**.\n\nJe peux vous aider à :\n• Rédiger des réponses pro à vos clients\n• Résumer vos conversations\n• Préparer des devis personnalisés\n• Répondre avec vos tarifs et horaires\n\nQue souhaitez-vous faire aujourd'hui ?`,
      timestamp: new Date().toISOString(),
    },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const [selectedContact, setSelectedContact] = useState<CRMContact | null>(null);
  const [selectedDevis, setSelectedDevis] = useState<Devis | null>(null);
  const [selectedConv, setSelectedConv] = useState<Conversation | null>(null);
  const [showContactModal, setShowContactModal] = useState(false);
  const [showDevisModal, setShowDevisModal] = useState(false);
  const [showConvModal, setShowConvModal] = useState(false);
  const [showApptModal, setShowApptModal] = useState(false);
  const [newContactForm, setNewContactForm] = useState<Partial<CRMContact>>({});
  const [newDevisForm, setNewDevisForm] = useState<{ contactId: string; lignes: DevisLigne[]; notes: string }>({ contactId: '', lignes: [{ id: '1', description: '', quantite: 1, prixUnitaire: 0 }], notes: '' });
  const [searchQuery, setSearchQuery] = useState('');

  // Onboarding
  const [onboardingStep, setOnboardingStep] = useState(0);

  // Quotas
  const quotas = {
    starter: { ia: 200, contacts: 100, devis: 20, auto: false },
    pro: { ia: 1000, contacts: 500, devis: 100, auto: true },
    business: { ia: 10000, contacts: 5000, devis: 1000, auto: true },
  };
  const usage = { ia: 342, contacts: contacts.length, devis: devis.length };

  useEffect(() => {
    (async () => {
      try {
        const savedLogin = await AsyncStorage.getItem('nexora_login');
        const savedBusiness = await AsyncStorage.getItem('nexora_business');
        const savedContacts = await AsyncStorage.getItem('nexora_contacts');
        const savedOnboarding = await AsyncStorage.getItem('nexora_onboarding');
        if (savedLogin) setIsLoggedIn(JSON.parse(savedLogin));
        if (savedBusiness) setBusiness(JSON.parse(savedBusiness));
        if (savedContacts) setContacts(JSON.parse(savedContacts));
        if (savedOnboarding) setOnboardingDone(JSON.parse(savedOnboarding));
        if (savedLogin && JSON.parse(savedLogin)) {
          if (savedOnboarding && JSON.parse(savedOnboarding)) {
            setCurrentScreen('dashboard');
          } else {
            setCurrentScreen('onboarding');
          }
        }
      } catch {}
      setLoading(false);
    })();
  }, []);

  const persist = async (key: string, value: any) => {
    try {
      await AsyncStorage.setItem(key, JSON.stringify(value));
    } catch {}
  };

  const handleLogin = () => {
    setIsLoggedIn(true);
    persist('nexora_login', true);
    if (!onboardingDone) {
      setCurrentScreen('onboarding');
    } else {
      setCurrentScreen('dashboard');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    persist('nexora_login', false);
    setCurrentScreen('landing');
    setDrawerOpen(false);
  };

  const handleCompleteOnboarding = () => {
    setOnboardingDone(true);
    persist('nexora_onboarding', true);
    persist('nexora_business', business);
    setCurrentScreen('dashboard');
  };

  // ================= AI LOGIC =================
  const generateAIResponse = (input: string): string => {
    const lower = input.toLowerCase();
    const biz = business;
    const tonStyle = biz.ton === 'amical' ? 'chaleureux et proche' : biz.ton === 'formel' ? 'très formel et distingué' : biz.ton === 'detendu' ? 'décontracté et moderne' : 'professionnel et courtois';

    if (lower.includes('devis') || lower.includes('prépare') || lower.includes('prix')) {
      return `Bien sûr ! Voici un devis type pour **${biz.nom}** :\n\n📋 **Basé sur vos tarifs :**\n${biz.services.map(s => `• ${s.nom} : ${s.prix}€ (${s.duree})`).join('\n')}\n\n**Modèle de réponse client (ton ${tonStyle}) :**\n> "Bonjour [Prénom],\n> Merci pour votre demande ! Pour la prestation souhaitée, je vous propose :\n> [Détail prestation] - [Prix]€. Créneau disponible sous 48h.\n> Le devis est valable 30 jours.\n> Bien à vous, ${biz.nom} - ${biz.telephone}"\n\nVoulez-vous que je génère le PDF officiel ?`;
    }
    if (lower.includes('résum') || lower.includes('resume')) {
      return `📝 **Résumé intelligent de vos conversations récentes :**\n\n• 3 nouveaux prospects cette semaine (+25%)\n• Marie Dubois : demande coloration, devis envoyé, en attente réponse\n• Sophie Leroy : projet mariage 5 pers., gros potentiel (~510€ TTC)\n• Taux de réponse : 94% (au-dessus de la moyenne)\n\n**Action recommandée :** Relancer Marie (2 jours sans réponse) et finaliser le devis mariage.\n\nJe peux rédiger les messages de relance si vous voulez.`;
    }
    if (lower.includes('répond') || lower.includes('client a dit') || lower.includes('que répondre')) {
      return `Voici une réponse professionnelle adaptée à votre charte (**ton ${tonStyle}**) :\n\n> "Bonjour ! Merci beaucoup pour votre message. Nous serions ravis de vous accueillir chez ${biz.nom}.\n> \n> ${biz.horaires}. Nous proposons : ${biz.tarifs}.\n> \n> Pourriez-vous me préciser la date qui vous arrangerait ? Je vous trouve un créneau sous 24h.\n> \n> À très vite,\n> L'équipe ${biz.nom}\n> ${biz.telephone} | ${biz.email}"\n\n✏️ Cette réponse respecte vos règles : "${biz.regles}"`;
    }
    if (lower.includes('horaire') || lower.includes('ouvert') || lower.includes('tarif')) {
      return `**Informations officielles ${biz.nom} :**\n\n🕒 **Horaires :** ${biz.horaires}\n💰 **Tarifs :** ${biz.tarifs}\n📍 **Adresse :** ${biz.adresse}\n📞 **Contact :** ${biz.telephone} / ${biz.email}\n\n**Services :**\n${biz.services.map(s => `• ${s.nom} - ${s.prix}€`).join('\n')}\n\nJe peux intégrer ces infos automatiquement dans toutes vos réponses clients.`;
    }
    if (lower.includes('conversion') || lower.includes('stat') || lower.includes('performance')) {
      return `📊 **Analyse de performance - ${biz.nom}**\n\n• Prospects : 12 ce mois (+34% vs mois dernier)\n• Conversion : 62% (devise envoyés → acceptés)\n• RDV moyen : 68€\n• Temps de réponse moyen : 1h24 (objectif <2h ✅)\n• IA : ${usage.ia} messages utilisés / ${quotas[plan].ia} (${Math.round(usage.ia / quotas[plan].ia * 100)}%)\n\n**Insight IA :** Vos devis le matin (9h-11h) convertissent 23% mieux. Pensez à programmer les envois !`;
    }
    return `Compris ! En tant qu'assistant de **${biz.nom}** (${biz.secteur}), avec un ton **${tonStyle}**, voici ma proposition :\n\n> "Bonjour, merci pour votre message ! Chez ${biz.nom}, nous mettons un point d'honneur à vous offrir un service de qualité.\n> \n> ${biz.services[0]?.nom ? `Concernant ${biz.services[0].nom}, nous proposons cette prestation à partir de ${biz.services[0].prix}€.` : ''}\n> \n> Nous sommes disponibles ${biz.horaires.toLowerCase()}. N'hésitez pas à me dire ce qui vous arrangerait.\n> \n> Belle journée,\n> ${biz.nom}"\n\nSouhaitez-vous que j'adapte cette réponse, que je crée un devis ou que je résume une conversation ?`;
  };

  const handleSendChat = () => {
    if (!chatInput.trim()) return;
    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', content: chatInput, timestamp: new Date().toISOString() };
    setChatMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setIsTyping(true);
    setTimeout(() => {
      const aiResp: ChatMessage = { id: (Date.now() + 1).toString(), role: 'assistant', content: generateAIResponse(userMsg.content), timestamp: new Date().toISOString() };
      setChatMessages(prev => [...prev, aiResp]);
      setIsTyping(false);
    }, 1100 + Math.random() * 800);
  };

  const calculateDevisTotal = (lignes: DevisLigne[], tva: number) => {
    const ht = lignes.reduce((sum, l) => sum + l.quantite * l.prixUnitaire, 0);
    const tvaAmt = ht * (tva / 100);
    return { ht, tva: tvaAmt, ttc: ht + tvaAmt };
  };

  const handleCreateDevis = () => {
    if (!newDevisForm.contactId) return;
    const contact = contacts.find(c => c.id === newDevisForm.contactId);
    const newId = `d${Date.now()}`;
    const newDevis: Devis = {
      id: newId,
      numero: `DEV-2026-${String(devis.length + 42).padStart(3, '0')}`,
      contactId: newDevisForm.contactId,
      contactNom: contact ? `${contact.prenom} ${contact.nom}` : 'Client',
      lignes: newDevisForm.lignes.filter(l => l.description),
      tva: 20,
      statut: 'brouillon',
      createdAt: new Date().toISOString().split('T')[0],
      validite: new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString().split('T')[0],
      notes: newDevisForm.notes,
    };
    setDevis([newDevis, ...devis]);
    setShowDevisModal(false);
    setNewDevisForm({ contactId: '', lignes: [{ id: '1', description: '', quantite: 1, prixUnitaire: 0 }], notes: '' });
  };

  const handleCreateContact = () => {
    const newC: CRMContact = {
      id: Date.now().toString(),
      nom: (newContactForm.nom as string) || '',
      prenom: (newContactForm.prenom as string) || '',
      email: (newContactForm.email as string) || '',
      telephone: (newContactForm.telephone as string) || '',
      entreprise: (newContactForm.entreprise as string) || '',
      status: (newContactForm.status as ContactStatus) || 'nouveau',
      notes: (newContactForm.notes as string) || '',
      createdAt: new Date().toISOString().split('T')[0],
      historique: ['Créé via Nexora'],
      source: 'Manuel',
    };
    const updated = [newC, ...contacts];
    setContacts(updated);
    persist('nexora_contacts', updated);
    setShowContactModal(false);
    setNewContactForm({});
  };

  if (!fontsLoaded || loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: COLORS.navy }}>
        <ActivityIndicator color={COLORS.violetLight} size="large" />
        <Text style={{ color: 'white', marginTop: 16, fontWeight: '700' }}>Nexora AI</Text>
      </View>
    );
  }

  // ================= UI COMPONENTS =================
  const PremiumButton = ({ title, onPress, variant = 'primary', icon, small, disabled }: any) => (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled}
      style={[
        styles.btn,
        variant === 'primary' && styles.btnPrimary,
        variant === 'secondary' && styles.btnSecondary,
        variant === 'ghost' && styles.btnGhost,
        small && { paddingVertical: 10, paddingHorizontal: 16 },
        disabled && { opacity: 0.5 },
      ]}
    >
      {variant === 'primary' ? (
        <LinearGradient colors={[COLORS.violet, COLORS.violetDark]} style={[StyleSheet.absoluteFill, { borderRadius: 14 }]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} />
      ) : null}
      {icon && <Ionicons name={icon} size={18} color={variant === 'primary' ? 'white' : COLORS.navy} style={{ marginRight: 8 }} />}
      <Text style={[styles.btnText, variant !== 'primary' && { color: COLORS.navy }, small && { fontSize: 14 }]}>{title}</Text>
    </TouchableOpacity>
  );

  const StatCard = ({ icon, label, value, trend, color }: any) => (
    <View style={styles.statCard}>
      <View style={[styles.statIcon, { backgroundColor: color + '15' }]}>
        <Ionicons name={icon} size={20} color={color} />
      </View>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
      {trend && (
        <View style={styles.trend}>
          <Ionicons name={trend > 0 ? 'trending-up' : 'trending-down'} size={12} color={trend > 0 ? COLORS.success : COLORS.error} />
          <Text style={[styles.trendText, { color: trend > 0 ? COLORS.success : COLORS.error }]}>{Math.abs(trend)}%</Text>
        </View>
      )}
    </View>
  );

  // ================= SCREENS =================

  const LandingScreen = () => (
    <ScrollView style={{ flex: 1, backgroundColor: COLORS.bg }} contentContainerStyle={{ paddingBottom: 40 }}>
      {/* Header */}
      <View style={styles.landingHeader}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <LinearGradient colors={[COLORS.violet, COLORS.violetDark]} style={styles.logoBox}>
            <Text style={styles.logoText}>N</Text>
          </LinearGradient>
          <Text style={styles.logoName}>Nexora<Text style={{ fontWeight: '400', color: COLORS.violet }}> AI</Text></Text>
        </View>
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <TouchableOpacity onPress={() => setCurrentScreen('login')} style={styles.headerLink}>
            <Text style={styles.headerLinkText}>Connexion</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setCurrentScreen('register')} style={styles.headerCta}>
            <Text style={styles.headerCtaText}>Commencer</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Hero */}
      <View style={styles.hero}>
        <LinearGradient colors={[COLORS.navy, COLORS.navy2, '#2A2250']} style={StyleSheet.absoluteFill} />
        <View style={styles.heroBadge}>
          <View style={styles.heroDot} />
          <Text style={styles.heroBadgeText}>Nouveau — IA entraînée pour artisans</Text>
        </View>
        <Text style={styles.heroTitle}>L'assistant IA qui fait grandir votre entreprise.</Text>
        <Text style={styles.heroSub}>Gagnez 12h par semaine. Nexora répond à vos clients, crée vos devis et organise vos RDV — automatiquement, à votre ton.</Text>
        <View style={{ flexDirection: 'row', gap: 12, marginTop: 28 }}>
          <TouchableOpacity onPress={() => setCurrentScreen('register')} style={{ flex: 1 }}>
            <LinearGradient colors={[COLORS.violet, COLORS.violetBright]} style={styles.heroPrimaryBtn} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
              <Text style={styles.heroPrimaryBtnText}>Essai gratuit 14 jours</Text>
              <Ionicons name="arrow-forward" size={18} color="white" />
            </LinearGradient>
          </TouchableOpacity>
        </View>
        <Text style={styles.heroTrust}>Sans CB • Installation en 3 min • Données en France 🇫🇷</Text>

        {/* Dashboard Preview */}
        <View style={styles.previewCard}>
          <View style={styles.previewHeader}>
            <View style={{ flexDirection: 'row', gap: 6 }}>
              <View style={[styles.previewDot, { backgroundColor: '#FF5F57' }]} />
              <View style={[styles.previewDot, { backgroundColor: '#FFBD2E' }]} />
              <View style={[styles.previewDot, { backgroundColor: '#28CA42' }]} />
            </View>
            <Text style={styles.previewHeaderText}>Tableau de bord • Atelier Lumière</Text>
            <Ionicons name="ellipsis-horizontal" size={16} color={COLORS.text3} />
          </View>
          <View style={{ flexDirection: 'row', gap: 10, padding: 16 }}>
            <View style={{ flex: 1, gap: 10 }}>
              <View style={styles.previewStat}>
                <Text style={styles.previewStatLabel}>Prospects</Text>
                <Text style={styles.previewStatValue}>12 +34%</Text>
              </View>
              <View style={styles.previewStat}>
                <Text style={styles.previewStatLabel}>Devis envoyés</Text>
                <Text style={styles.previewStatValue}>8  •  5 acceptés</Text>
              </View>
            </View>
            <View style={styles.previewChat}>
              <View style={styles.previewChatBubble}>
                <Text style={styles.previewChatText}>Une cliente demande un devis mariage 5 pers. Tu prépares ?</Text>
              </View>
              <View style={[styles.previewChatBubble, styles.previewChatBubbleAI]}>
                <Text style={[styles.previewChatText, { color: 'white' }]}>Devis prêt : 510€ TTC, dispo 15 nov. Envoi auto ?</Text>
              </View>
            </View>
          </View>
        </View>
      </View>

      {/* Logos */}
      <View style={styles.logosRow}>
        <Text style={styles.logosLabel}>Ils font confiance à Nexora</Text>
        <View style={{ flexDirection: 'row', justifyContent: 'space-around', marginTop: 12 }}>
          {['Coiffeur', 'Garage', 'Artisan', 'Agence'].map(b => (
            <View key={b} style={styles.logoPill}><Text style={styles.logoPillText}>{b}</Text></View>
          ))}
        </View>
      </View>

      {/* Features Grid */}
      <View style={styles.section}>
        <Text style={styles.sectionTag}>FONCTIONNALITÉS</Text>
        <Text style={styles.sectionTitle}>Tout pour vendre plus, sans travailler plus.</Text>
        <View style={styles.featuresGrid}>
          {[
            { icon: 'chatbubbles', title: 'Assistant IA', desc: 'Rédige des réponses parfaites avec vos tarifs, horaires et votre ton.' },
            { icon: 'people', title: 'Mini-CRM', desc: 'Prospects, clients, notes et historique. Tout au même endroit.' },
            { icon: 'document-text', title: 'Devis auto', desc: 'Génération, calcul TVA, PDF pro et suivi acceptation.' },
            { icon: 'calendar', title: 'RDV intelligents', desc: 'Calendrier, dispos, rappels SMS auto J-1.' },
            { icon: 'flash', title: 'Automatisations', desc: 'Relances, thank you, avis Google. Sans y penser.' },
            { icon: 'stats-chart', title: 'Stats claires', desc: 'Prospects, conversions, CA estimé. Pas de bullshit.' },
          ].map(f => (
            <View key={f.title} style={styles.featureCard}>
              <View style={styles.featureIcon}><Ionicons name={f.icon as any} size={22} color={COLORS.violet} /></View>
              <Text style={styles.featureTitle}>{f.title}</Text>
              <Text style={styles.featureDesc}>{f.desc}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Pricing Preview */}
      <View style={[styles.section, { backgroundColor: 'white' }]}>
        <Text style={styles.sectionTag}>TARIFS SIMPLES</Text>
        <Text style={styles.sectionTitle}>Commencez petit, scalez sans limites.</Text>
        <View style={{ gap: 16, marginTop: 20 }}>
          {[
            { name: 'Starter', price: planPrices.starter, feat: ['200 msg IA/mois', '100 contacts', '20 devis', 'Support email'] },
            { name: 'Pro', price: planPrices.pro, feat: ['1 000 msg IA', '500 contacts', '100 devis', 'Automatisations', 'Support prio'], pop: true },
            { name: 'Business', price: planPrices.business, feat: ['10 000 msg IA', '5 000 contacts', 'Devis illimités', 'API + Webhooks', 'Dédié'] },
          ].map(p => (
            <View key={p.name} style={[styles.pricingCard, p.pop && styles.pricingPop]}>
              {p.pop && <View style={styles.popBadge}><Text style={styles.popBadgeText}>Le plus choisi</Text></View>}
              <Text style={styles.pricingName}>{p.name}</Text>
              <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 4 }}>
                <Text style={styles.pricingPrice}>{p.price}€</Text><Text style={styles.pricingPer}>/mois</Text>
              </View>
              <View style={{ gap: 8, marginTop: 16 }}>
                {p.feat.map(fe => (
                  <View key={fe} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                    <Ionicons name="checkmark-circle" size={18} color={COLORS.success} />
                    <Text style={styles.pricingFeat}>{fe}</Text>
                  </View>
                ))}
              </View>
              <TouchableOpacity onPress={() => setCurrentScreen('register')} style={[styles.pricingBtn, p.pop && { backgroundColor: COLORS.navy }]}>
                <Text style={[styles.pricingBtnText, p.pop && { color: 'white' }]}>Choisir {p.name}</Text>
              </TouchableOpacity>
            </View>
          ))}
        </View>
      </View>

      <View style={styles.ctaFinal}>
        <LinearGradient colors={[COLORS.navy, COLORS.violetDark]} style={StyleSheet.absoluteFill} />
        <Text style={styles.ctaFinalTitle}>Prêt à récupérer 12h par semaine ?</Text>
        <Text style={styles.ctaFinalSub}>Rejoignez 1 200+ petites entreprises qui automatisent déjà avec Nexora.</Text>
        <TouchableOpacity onPress={() => setCurrentScreen('register')} style={styles.ctaFinalBtn}>
          <Text style={styles.ctaFinalBtnText}>Créer mon compte — gratuit 14j</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.footer}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <LinearGradient colors={[COLORS.violet, COLORS.violetDark]} style={[styles.logoBox, { width: 28, height: 28, borderRadius: 8 }]}>
            <Text style={[styles.logoText, { fontSize: 14 }]}>N</Text>
          </LinearGradient>
          <Text style={{ fontWeight: '800', color: COLORS.text }}>Nexora AI</Text>
        </View>
        <View style={{ flexDirection: 'row', gap: 16, marginTop: 16, flexWrap: 'wrap' }}>
          {[
            { l: 'Fonctionnalités', s: 'features' },
            { l: 'Tarifs', s: 'pricing' },
            { l: 'FAQ', s: 'faq' },
            { l: 'CGU & Confidentialité', s: 'cgv' },
          ].map(i => (
            <TouchableOpacity key={i.s} onPress={() => setCurrentScreen(i.s as ScreenName)}><Text style={styles.footerLink}>{i.l}</Text></TouchableOpacity>
          ))}
        </View>
        <Text style={styles.footerCopy}>© 2026 Nexora SAS • Données hébergées en UE • RGPD • contact@nexora.ai</Text>
      </View>
    </ScrollView>
  );

  const FeaturesScreen = () => (
    <ScrollView style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <View style={styles.pageHeader}>
        <TouchableOpacity onPress={() => setCurrentScreen('landing')} style={styles.backBtn}><Ionicons name="arrow-back" size={22} color={COLORS.navy} /></TouchableOpacity>
        <Text style={styles.pageTitle}>Fonctionnalités</Text>
      </View>
      <View style={{ padding: 20, gap: 16 }}>
        {[
          { title: 'Assistant IA contextuel', desc: 'Entraîné sur votre entreprise : nom, secteur, services, ton, horaires. Il ne hallucine jamais vos prix.', icon: 'sparkles', color: COLORS.violet },
          { title: 'Configuration IA complète', desc: 'Nom, secteur (coiffeur, garage, artisan, freelance, agence), services, tarifs, horaires, ton de communication et règles de réponse.', icon: 'settings', color: COLORS.blue },
          { title: 'Mini-CRM ultra simple', desc: 'Création, recherche, statuts (prospect/client/archivé), notes, source d’acquisition et historique complet.', icon: 'people', color: COLORS.success },
          { title: 'Devis PDF pro', desc: 'Calcul HT/TVA/TTC auto, numérotation, export PDF premium, suivi brouillon/envoyé/accepté/refusé.', icon: 'document', color: COLORS.warning },
          { title: 'Boîte de réception unifiée', desc: 'Toutes vos conversations clients au même endroit, avec brouillons IA et attribution.', icon: 'mail', color: COLORS.navy },
          { title: 'Rendez-vous', desc: 'Calendrier mensuel, disponibilités, réservations, rappels automatiques et statuts.', icon: 'calendar', color: COLORS.violet },
          { title: 'Automatisations', desc: 'Relance devis J+3, rappel RDV J-1, merci + demande avis Google. Activez/désactivez en 1 clic.', icon: 'flash', color: '#E11D48' },
          { title: 'Statistiques actionnables', desc: 'Prospects, conversions, CA estimé et consommation IA avec graphiques lisibles.', icon: 'bar-chart', color: COLORS.blue },
          { title: 'Abonnements & quotas', desc: 'Gestion forfaits, quotas IA, paiements sécurisés. Fonctionnalités débloquées selon le plan.', icon: 'card', color: COLORS.success },
          { title: 'Multi-entreprise & sécurité', desc: 'Isolation stricte des données, RLS côté serveur, validation entrées, clés jamais exposées.', icon: 'shield-checkmark', color: COLORS.navy },
        ].map(f => (
          <View key={f.title} style={styles.featureDetail}>
            <View style={[styles.featureDetailIcon, { backgroundColor: f.color + '15' }]}><Ionicons name={f.icon as any} size={24} color={f.color} /></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.featureDetailTitle}>{f.title}</Text>
              <Text style={styles.featureDetailDesc}>{f.desc}</Text>
            </View>
          </View>
        ))}
        <PremiumButton title="Voir les tarifs" onPress={() => setCurrentScreen('pricing')} icon="pricetags" />
      </View>
    </ScrollView>
  );

  const PricingScreen = () => (
    <ScrollView style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <View style={styles.pageHeader}>
        <TouchableOpacity onPress={() => setCurrentScreen(isLoggedIn ? 'subscription' : 'landing')} style={styles.backBtn}><Ionicons name="arrow-back" size={22} color={COLORS.navy} /></TouchableOpacity>
        <Text style={styles.pageTitle}>Tarifs</Text>
        {isLoggedIn && <TouchableOpacity onPress={() => setEditingPrices(!editingPrices)} style={{ padding: 6 }}><Ionicons name={editingPrices ? 'checkmark' : 'create-outline'} size={20} color={COLORS.violet} /></TouchableOpacity>}
      </View>
      <View style={{ padding: 20 }}>
        <Text style={{ fontSize: 28, fontWeight: '800', color: COLORS.navy, lineHeight: 34 }}>Des prix justes.{"\n"}Pas de surprise.</Text>
        <Text style={{ color: COLORS.text2, marginTop: 8 }}>Modifiez les prix depuis l'admin. Fonctionnalités débloquées selon le forfait.</Text>
        <View style={{ gap: 16, marginTop: 24 }}>
          {(Object.keys(planPrices) as PlanType[]).map(k => {
            const isCurrent = plan === k;
            return (
              <View key={k} style={[styles.pricingCard, isCurrent && { borderColor: COLORS.violet, borderWidth: 1.5 }]}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Text style={styles.pricingName}>{k.charAt(0).toUpperCase() + k.slice(1)}</Text>
                  {isCurrent && <View style={{ backgroundColor: COLORS.violetSoft, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 }}><Text style={{ color: COLORS.violet, fontSize: 12, fontWeight: '700' }}>Actuel</Text></View>}
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 8 }}>
                  {editingPrices ? (
                    <TextInput value={String(planPrices[k])} onChangeText={t => setPlanPrices(p => ({ ...p, [k]: parseInt(t) || 0 }))} keyboardType="numeric" style={{ borderWidth: 1, borderColor: COLORS.border, borderRadius: 8, padding: 8, width: 80, fontWeight: '800', fontSize: 20 }} />
                  ) : (
                    <Text style={styles.pricingPrice}>{planPrices[k]}€</Text>
                  )}
                  <Text style={styles.pricingPer}>/mois HT</Text>
                </View>
                <View style={{ marginTop: 12, gap: 6 }}>
                  <Text style={styles.quotaText}>• {quotas[k].ia} messages IA</Text>
                  <Text style={styles.quotaText}>• {quotas[k].contacts} contacts CRM</Text>
                  <Text style={styles.quotaText}>• {quotas[k].devis} devis</Text>
                  <Text style={styles.quotaText}>• Automatisations : {quotas[k].auto ? 'Oui' : 'Non'}</Text>
                </View>
                {!isLoggedIn ? (
                  <TouchableOpacity onPress={() => setCurrentScreen('register')} style={[styles.pricingBtn, { marginTop: 16, backgroundColor: COLORS.navy }]}>
                    <Text style={[styles.pricingBtnText, { color: 'white' }]}>Commencer avec {k}</Text>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity onPress={() => setPlan(k)} style={[styles.pricingBtn, { marginTop: 16, backgroundColor: isCurrent ? COLORS.border : COLORS.navy }]}>
                    <Text style={[styles.pricingBtnText, { color: isCurrent ? COLORS.text3 : 'white' }]}>{isCurrent ? 'Forfait actuel' : `Passer à ${k}`}</Text>
                  </TouchableOpacity>
                )}
              </View>
            );
          })}
        </View>
        <View style={{ backgroundColor: COLORS.violetSoft, borderRadius: 16, padding: 16, marginTop: 24 }}>
          <Text style={{ fontWeight: '700', color: COLORS.violetDark }}>🔒 Paiement sécurisé — Stripe / PayPal compatible UE</Text>
          <Text style={{ color: COLORS.text2, marginTop: 6, fontSize: 13 }}>Prélèvement mensuel, annulation en 1 clic. Factures auto. Quotas appliqués côté serveur.</Text>
        </View>
      </View>
    </ScrollView>
  );

  const FAQScreen = () => (
    <ScrollView style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <View style={styles.pageHeader}>
        <TouchableOpacity onPress={() => setCurrentScreen('landing')} style={styles.backBtn}><Ionicons name="arrow-back" size={22} color={COLORS.navy} /></TouchableOpacity>
        <Text style={styles.pageTitle}>FAQ</Text>
      </View>
      <View style={{ padding: 20, gap: 12 }}>
        {[
          { q: 'Nexora est-il vraiment adapté aux coiffeurs / garages / artisans ?', a: 'Oui, c’est notre cœur de cible. On a modélisé les services, durées, tarifs, horaires atypiques et le ton amical/pro. Le setup prend 3 min.' },
          { q: 'Mes données sont-elles isolées ?', a: 'Architecture multi-tenant stricte : chaque entreprise a son ID, RLS PostgreSQL, JWT côté serveur, aucune clé API exposée navigateur. Hébergement UE, RGPD.' },
          { q: 'L’IA peut-elle inventer mes prix ?', a: 'Non. Elle est contrainte par votre configuration (services, tarifs, règles). Sans config, elle demande. Avec RAG, elle cite vos sources.' },
          { q: 'Puis-je exporter mes devis en PDF ?', a: 'Oui. Numérotation automatique, calcul HT/TVA/TTC, mentions légales et export PDF pro prêt à envoyer.' },
          { q: 'Comment fonctionne le paiement ?', a: 'Via prestataire compatible pays d’enregistrement (Stripe en UE). Webhooks sécurisés, quotas appliqués serveur, pas de simulation.' },
          { q: 'Que se passe-t-il si ma clé API manque ?', a: 'L’interface affiche clairement le message de configuration manquante avec lien vers .env.example et docs. Aucun faux succès.' },
          { q: 'Technos utilisées ?', a: 'Frontend Next.js/React/TS/Tailwind (ici adapté en React Native + Expo pour mobile). Backend Supabase/Postgres + Auth, Edge Functions pour IA et webhooks paiement.' },
        ].map((f, i) => (
          <View key={i} style={{ backgroundColor: 'white', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: COLORS.border }}>
            <Text style={{ fontWeight: '700', color: COLORS.navy }}>{f.q}</Text>
            <Text style={{ color: COLORS.text2, marginTop: 8, lineHeight: 20 }}>{f.a}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );

  const CGVScreen = () => (
    <ScrollView style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <View style={styles.pageHeader}>
        <TouchableOpacity onPress={() => setCurrentScreen('landing')} style={styles.backBtn}><Ionicons name="arrow-back" size={22} color={COLORS.navy} /></TouchableOpacity>
        <Text style={styles.pageTitle}>CGU & Confidentialité</Text>
      </View>
      <View style={{ padding: 20 }}>
        <Text style={{ fontSize: 13, lineHeight: 20, color: COLORS.text2 }}>
          <Text style={{ fontWeight: '800', color: COLORS.navy }}>1. Objet{'\n'}</Text>
          Nexora AI est un SaaS d’assistance pour TPE. L’utilisateur s’engage à fournir des informations exactes sur son entreprise.{'\n\n'}
          <Text style={{ fontWeight: '800', color: COLORS.navy }}>2. Données & RGPD{'\n'}</Text>
          Données stockées UE, chiffrage AES-256, RLS Supabase, suppression sur demande, DPA disponible. Sous-traitants : Supabase (DB), OpenAI/Anthropic (IA), Stripe (paiement).{'\n\n'}
          <Text style={{ fontWeight: '800', color: COLORS.navy }}>3. IA & Responsabilité{'\n'}</Text>
          L’IA assiste, ne décide pas. L’utilisateur reste responsable des réponses envoyées et des devis. Quotas appliqués serveur.{'\n\n'}
          <Text style={{ fontWeight: '800', color: COLORS.navy }}>4. Paiement{'\n'}</Text>
          Abonnement mensuel, reconduction tacite, annulation avant renouvellement. Aucun remboursement prorata sauf obligation légale. Webhooks sécurisés, pas de simulation.{'\n\n'}
          <Text style={{ fontWeight: '800', color: COLORS.navy }}>5. Communications commerciales{'\n'}</Text>
          Respect art. L34-5 CPCE : consentement préalable, opt-out clair. Templates validés.{'\n\n'}
          <Text style={{ fontWeight: '800', color: COLORS.navy }}>6. .env.example{'\n'}</Text>
          NEXT_PUBLIC_SUPABASE_URL=...{'\n'}NEXT_PUBLIC_SUPABASE_ANON_KEY=...{'\n'}SUPABASE_SERVICE_ROLE_KEY=... (serveur uniquement){'\n'}OPENAI_API_KEY=...{'\n'}STRIPE_SECRET_KEY=...{'\n'}STRIPE_WEBHOOK_SECRET=...{'\n\n'}
          Les clés ne sont jamais exposées côté navigateur.
        </Text>
      </View>
    </ScrollView>
  );

  const AuthScreens = () => {
    const isLogin = currentScreen === 'login';
    const [email, setEmail] = useState(userEmail);
    const [pwd, setPwd] = useState('demo1234');
    return (
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1, backgroundColor: COLORS.bg }}>
        <ScrollView contentContainerStyle={{ flexGrow: 1, padding: 24, justifyContent: 'center' }}>
          <TouchableOpacity onPress={() => setCurrentScreen('landing')} style={{ position: 'absolute', top: Platform.OS === 'web' ? 20 : 60, left: 24, flexDirection: 'row', alignItems: 'center', gap: 6 }}>
            <Ionicons name="arrow-back" size={20} color={COLORS.navy} /><Text style={{ color: COLORS.navy, fontWeight: '600' }}>Accueil</Text>
          </TouchableOpacity>
          <View style={{ alignItems: 'center', marginBottom: 32, marginTop: 60 }}>
            <LinearGradient colors={[COLORS.violet, COLORS.navy]} style={{ width: 64, height: 64, borderRadius: 20, justifyContent: 'center', alignItems: 'center' }}>
              <Text style={{ color: 'white', fontWeight: '900', fontSize: 28 }}>N</Text>
            </LinearGradient>
            <Text style={{ fontSize: 28, fontWeight: '800', color: COLORS.navy, marginTop: 16 }}>{isLogin ? 'Bon retour !' : 'Créez votre compte'}</Text>
            <Text style={{ color: COLORS.text2, marginTop: 6, textAlign: 'center' }}>{isLogin ? 'Connectez-vous pour retrouver votre entreprise' : '14 jours gratuits, sans CB'}</Text>
          </View>
          <View style={{ backgroundColor: 'white', borderRadius: 20, padding: 20, borderWidth: 1, borderColor: COLORS.border, gap: 14 }}>
            <View>
              <Text style={styles.inputLabel}>Email pro</Text>
              <View style={styles.inputWrapper}>
                <Ionicons name="mail-outline" size={18} color={COLORS.text3} />
                <TextInput value={email} onChangeText={setEmail} placeholder="vous@entreprise.fr" keyboardType="email-address" autoCapitalize="none" style={styles.input} />
              </View>
            </View>
            <View>
              <Text style={styles.inputLabel}>Mot de passe</Text>
              <View style={styles.inputWrapper}>
                <Ionicons name="lock-closed-outline" size={18} color={COLORS.text3} />
                <TextInput value={pwd} onChangeText={setPwd} placeholder="••••••••" secureTextEntry style={styles.input} />
              </View>
            </View>
            {!isLogin && (
              <View style={{ backgroundColor: COLORS.violetSoft, borderRadius: 12, padding: 12 }}>
                <Text style={{ fontSize: 12, color: COLORS.violetDark, lineHeight: 16 }}>✓ Multi-entreprise isolée (RLS)  ✓ Données UE  ✓ Chiffrage  ✓ RGPD</Text>
              </View>
            )}
            <PremiumButton title={isLogin ? 'Se connecter' : 'Créer mon compte'} onPress={() => { setUserEmail(email); handleLogin(); }} icon={isLogin ? 'log-in' : 'rocket'} />
            <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 6 }}>
              <Text style={{ color: COLORS.text2 }}>{isLogin ? 'Pas encore de compte ?' : 'Déjà inscrit ?'}</Text>
              <TouchableOpacity onPress={() => setCurrentScreen(isLogin ? 'register' : 'login')}><Text style={{ color: COLORS.violet, fontWeight: '700' }}>{isLogin ? "S'inscrire" : 'Se connecter'}</Text></TouchableOpacity>
            </View>
          </View>
          <Text style={{ textAlign: 'center', color: COLORS.text3, fontSize: 12, marginTop: 16 }}>En continuant, vous acceptez nos <Text onPress={() => setCurrentScreen('cgv')} style={{ color: COLORS.violet, fontWeight: '600' }}>CGU & Confidentialité</Text></Text>
        </ScrollView>
      </KeyboardAvoidingView>
    );
  };

  const OnboardingWizard = () => {
    const steps = [
      { title: 'Votre entreprise', fields: ['nom', 'secteur'] },
      { title: 'Vos services', fields: ['services'] },
      { title: 'Coordonnées & horaires', fields: ['contact'] },
      { title: 'Ton & règles IA', fields: ['ia'] },
    ];
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.bg }}>
        <View style={{ padding: 20 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={{ fontWeight: '800', fontSize: 18, color: COLORS.navy }}>Configuration</Text>
            <Text style={{ color: COLORS.text3 }}>{onboardingStep + 1}/4</Text>
          </View>
          <View style={{ flexDirection: 'row', gap: 6, marginTop: 16 }}>
            {[0, 1, 2, 3].map(i => (
              <View key={i} style={{ flex: 1, height: 6, borderRadius: 3, backgroundColor: i <= onboardingStep ? COLORS.violet : COLORS.border }} />
            ))}
          </View>
        </View>
        <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 20 }}>
          {onboardingStep === 0 && (
            <View style={{ gap: 16 }}>
              <Text style={styles.onboardTitle}>Comment s'appelle votre entreprise ?</Text>
              <Text style={styles.onboardSub}>Ces infos entraînent votre assistant IA.</Text>
              <View>
                <Text style={styles.inputLabel}>Nom de l'entreprise *</Text>
                <TextInput value={business.nom} onChangeText={t => setBusiness({ ...business, nom: t })} placeholder="Ex: Atelier Lumière" style={styles.inputBox} />
              </View>
              <View>
                <Text style={styles.inputLabel}>Secteur d'activité</Text>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                  {['Coiffeur', 'Garage', 'Artisan', 'Freelance', 'Agence', 'Autre'].map(s => (
                    <TouchableOpacity key={s} onPress={() => setBusiness({ ...business, secteur: s })} style={[styles.secteurPill, business.secteur === s && styles.secteurPillActive]}>
                      <Text style={[styles.secteurText, business.secteur === s && styles.secteurTextActive]}>{s}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            </View>
          )}
          {onboardingStep === 1 && (
            <View style={{ gap: 16 }}>
              <Text style={styles.onboardTitle}>Quels services proposez-vous ?</Text>
              <Text style={styles.onboardSub}>Ajoutez vos prestations avec prix et durée. L'IA les utilisera pour les devis.</Text>
              {business.services.map((serv, idx) => (
                <View key={idx} style={{ backgroundColor: 'white', borderRadius: 14, padding: 12, borderWidth: 1, borderColor: COLORS.border, gap: 8 }}>
                  <TextInput value={serv.nom} onChangeText={t => { const ns = [...business.services]; ns[idx].nom = t; setBusiness({ ...business, services: ns }); }} placeholder="Nom service" style={styles.inputBox} />
                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    <TextInput value={String(serv.prix)} onChangeText={t => { const ns = [...business.services]; ns[idx].prix = parseInt(t) || 0; setBusiness({ ...business, services: ns }); }} placeholder="Prix €" keyboardType="numeric" style={[styles.inputBox, { flex: 1 }]} />
                    <TextInput value={serv.duree} onChangeText={t => { const ns = [...business.services]; ns[idx].duree = t; setBusiness({ ...business, services: ns }); }} placeholder="Durée" style={[styles.inputBox, { flex: 1 }]} />
                  </View>
                </View>
              ))}
              <TouchableOpacity onPress={() => setBusiness({ ...business, services: [...business.services, { nom: '', prix: 0, duree: '' }] })} style={{ borderWidth: 1, borderColor: COLORS.violet, borderStyle: 'dashed', borderRadius: 12, padding: 14, alignItems: 'center' }}>
                <Text style={{ color: COLORS.violet, fontWeight: '700' }}>+ Ajouter un service</Text>
              </TouchableOpacity>
              <View>
                <Text style={styles.inputLabel}>Description tarifs</Text>
                <TextInput value={business.tarifs} onChangeText={t => setBusiness({ ...business, tarifs: t })} placeholder="Ex: Coupe à partir de 25€..." multiline style={[styles.inputBox, { height: 80, textAlignVertical: 'top' }]} />
              </View>
            </View>
          )}
          {onboardingStep === 2 && (
            <View style={{ gap: 16 }}>
              <Text style={styles.onboardTitle}>Où vous trouver ?</Text>
              <TextInput value={business.adresse} onChangeText={t => setBusiness({ ...business, adresse: t })} placeholder="Adresse" style={styles.inputBox} />
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <TextInput value={business.telephone} onChangeText={t => setBusiness({ ...business, telephone: t })} placeholder="Téléphone" style={[styles.inputBox, { flex: 1 }]} keyboardType="phone-pad" />
                <TextInput value={business.email} onChangeText={t => setBusiness({ ...business, email: t })} placeholder="Email" style={[styles.inputBox, { flex: 1 }]} keyboardType="email-address" />
              </View>
              <TextInput value={business.horaires} onChangeText={t => setBusiness({ ...business, horaires: t })} placeholder="Horaires (ex: Mar-Sam 9h-19h)" style={styles.inputBox} />
            </View>
          )}
          {onboardingStep === 3 && (
            <View style={{ gap: 16 }}>
              <Text style={styles.onboardTitle}>Comment doit parler votre IA ?</Text>
              <Text style={styles.onboardSub}>Définissez le ton et les règles immuables.</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                {[
                  { id: 'professionnel', label: 'Professionnel' },
                  { id: 'amical', label: 'Amical' },
                  { id: 'formel', label: 'Formel' },
                  { id: 'detendu', label: 'Détendu' },
                ].map(t => (
                  <TouchableOpacity key={t.id} onPress={() => setBusiness({ ...business, ton: t.id as any })} style={[styles.secteurPill, business.ton === t.id && styles.secteurPillActive]}>
                    <Text style={[styles.secteurText, business.ton === t.id && styles.secteurTextActive]}>{t.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              <Text style={styles.inputLabel}>Règles de réponse IA</Text>
              <TextInput value={business.regles} onChangeText={t => setBusiness({ ...business, regles: t })} placeholder="Ex: Toujours vouvoyer, proposer créneau sous 48h..." multiline style={[styles.inputBox, { height: 100, textAlignVertical: 'top' }]} />
              <View style={{ backgroundColor: COLORS.violetSoft, borderRadius: 12, padding: 12 }}>
                <Text style={{ fontWeight: '700', color: COLORS.violetDark, fontSize: 13 }}>🛡️ Sécurité : cette config est isolée par entreprise_id + RLS. Aucune autre entreprise ne peut la voir.</Text>
              </View>
            </View>
          )}
        </ScrollView>
        <View style={{ padding: 20, flexDirection: 'row', gap: 12 }}>
          {onboardingStep > 0 && <TouchableOpacity onPress={() => setOnboardingStep(s => s - 1)} style={[styles.pricingBtn, { flex: 1, backgroundColor: 'white', borderWidth: 1, borderColor: COLORS.border }]}><Text style={{ fontWeight: '700', color: COLORS.navy }}>Retour</Text></TouchableOpacity>}
          <TouchableOpacity onPress={() => onboardingStep < 3 ? setOnboardingStep(s => s + 1) : handleCompleteOnboarding()} style={{ flex: 2 }}>
            <LinearGradient colors={[COLORS.violet, COLORS.violetDark]} style={{ borderRadius: 14, padding: 16, alignItems: 'center' }}><Text style={{ color: 'white', fontWeight: '800' }}>{onboardingStep < 3 ? 'Continuer' : "Terminer — Aller au tableau de bord"}</Text></LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  };

  // ================= MAIN APP LAYOUT =================
  const MainLayout = ({ children }: { children: React.ReactNode }) => (
    <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.bg }}>
      {/* Top Bar */}
      <View style={styles.topBar}>
        <TouchableOpacity onPress={() => setDrawerOpen(true)} style={styles.menuBtn}><Ionicons name="menu" size={24} color={COLORS.navy} /></TouchableOpacity>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <LinearGradient colors={[COLORS.violet, COLORS.violetDark]} style={{ width: 32, height: 32, borderRadius: 10, justifyContent: 'center', alignItems: 'center' }}><Text style={{ color: 'white', fontWeight: '900' }}>N</Text></LinearGradient>
          <View>
            <Text style={{ fontWeight: '800', color: COLORS.navy, fontSize: 14 }}>{business.nom}</Text>
            <Text style={{ fontSize: 11, color: COLORS.text3 }}>{plan.toUpperCase()} • {usage.ia}/{quotas[plan].ia} IA</Text>
          </View>
        </View>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <TouchableOpacity style={styles.topBarIcon} onPress={() => setCurrentScreen('conversations')}><Ionicons name="notifications-outline" size={20} color={COLORS.navy} /><View style={styles.notifDot} /></TouchableOpacity>
          <TouchableOpacity style={styles.topBarIcon} onPress={() => setCurrentScreen('config')}><Ionicons name="person-circle-outline" size={22} color={COLORS.navy} /></TouchableOpacity>
        </View>
      </View>

      <View style={{ flex: 1 }}>{children}</View>

      {/* Bottom Tabs */}
      <View style={styles.bottomTabs}>
        {[
          { id: 'dashboard', icon: 'grid-outline', active: 'grid', label: 'Accueil' },
          { id: 'assistant', icon: 'sparkles-outline', active: 'sparkles', label: 'Nexora IA' },
          { id: 'crm', icon: 'people-outline', active: 'people', label: 'CRM' },
          { id: 'devis', icon: 'document-text-outline', active: 'document-text', label: 'Devis' },
          { id: 'conversations', icon: 'chatbubbles-outline', active: 'chatbubbles', label: 'Messages' },
        ].map(tab => {
          const active = currentScreen === tab.id;
          return (
            <TouchableOpacity key={tab.id} onPress={() => setCurrentScreen(tab.id as ScreenName)} style={styles.tabItem}>
              <Ionicons name={(active ? tab.active : tab.icon) as any} size={22} color={active ? COLORS.violet : COLORS.text3} />
              <Text style={[styles.tabLabel, active && { color: COLORS.violet, fontWeight: '700' }]}>{tab.label}</Text>
              {tab.id === 'conversations' && conversations.filter(c => c.status === 'non_lu').length > 0 && <View style={styles.tabBadge}><Text style={styles.tabBadgeText}>{conversations.filter(c => c.status === 'non_lu').length}</Text></View>}
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Drawer */}
      <Modal visible={drawerOpen} animationType="fade" transparent onRequestClose={() => setDrawerOpen(false)}>
        <Pressable style={styles.drawerOverlay} onPress={() => setDrawerOpen(false)}>
          <Pressable style={styles.drawer} onPress={e => e.stopPropagation()}>
            <LinearGradient colors={[COLORS.navy, COLORS.navy2]} style={StyleSheet.absoluteFill} />
            <View style={{ padding: 20, paddingTop: 40 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                  <LinearGradient colors={[COLORS.violet, COLORS.violetBright]} style={{ width: 44, height: 44, borderRadius: 12, justifyContent: 'center', alignItems: 'center' }}><Text style={{ color: 'white', fontWeight: '900', fontSize: 18 }}>N</Text></LinearGradient>
                  <View><Text style={{ color: 'white', fontWeight: '800' }}>Nexora AI</Text><Text style={{ color: COLORS.violetBright, fontSize: 12 }}>{business.secteur} • {plan}</Text></View>
                </View>
                <TouchableOpacity onPress={() => setDrawerOpen(false)}><Ionicons name="close" size={24} color="white" /></TouchableOpacity>
              </View>
              <View style={{ backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 14, padding: 14, marginTop: 20 }}>
                <Text style={{ color: 'white', fontWeight: '700', fontSize: 14 }}>{business.nom}</Text>
                <Text style={{ color: 'rgba(255,255,255,0.6)', fontSize: 12, marginTop: 2 }}>{business.email}</Text>
                <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
                  <View style={styles.usagePill}><Text style={styles.usagePillText}>IA {Math.round(usage.ia / quotas[plan].ia * 100)}%</Text></View>
                  <View style={styles.usagePill}><Text style={styles.usagePillText}>CRM {contacts.length}/{quotas[plan].contacts}</Text></View>
                </View>
              </View>
            </View>
            <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 12 }}>
              {[
                { id: 'dashboard', label: 'Tableau de bord', icon: 'grid', desc: 'Vue d’ensemble' },
                { id: 'assistant', label: 'Assistant IA', icon: 'sparkles', desc: 'Chat + rédaction' },
                { id: 'config', label: 'Configuration IA', icon: 'settings', desc: 'Entreprise & ton' },
                { id: 'crm', label: 'CRM', icon: 'people', desc: `${contacts.length} contacts` },
                { id: 'devis', label: 'Devis', icon: 'document-text', desc: `${devis.length} devis` },
                { id: 'conversations', label: 'Conversations', icon: 'chatbubbles', desc: 'Boîte de réception' },
                { id: 'appointments', label: 'Rendez-vous', icon: 'calendar', desc: 'Planning & dispos' },
                { id: 'automations', label: 'Automatisations', icon: 'flash', desc: plan === 'starter' ? 'Pro requis' : `${automations.filter(a=>a.actif).length} actives` },
                { id: 'stats', label: 'Statistiques', icon: 'bar-chart', desc: 'Conversions & IA' },
                { id: 'subscription', label: 'Abonnement', icon: 'card', desc: `${planPrices[plan]}€/mois` },
                { id: 'admin', label: 'Administration', icon: 'shield-checkmark', desc: 'Users & logs' },
              ].map(item => (
                <TouchableOpacity key={item.id} onPress={() => { setCurrentScreen(item.id as ScreenName); setDrawerOpen(false); }} style={[styles.drawerItem, currentScreen === item.id && styles.drawerItemActive]}>
                  <View style={[styles.drawerIcon, currentScreen === item.id && { backgroundColor: COLORS.violet }]}>
                    <Ionicons name={item.icon as any} size={18} color={currentScreen === item.id ? 'white' : 'rgba(255,255,255,0.7)'} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.drawerLabel, currentScreen === item.id && { color: 'white' }]}>{item.label}</Text>
                    <Text style={styles.drawerDesc}>{item.desc}</Text>
                  </View>
                  {item.id === 'automations' && plan === 'starter' && <Ionicons name="lock-closed" size={14} color={COLORS.warning} />}
                </TouchableOpacity>
              ))}
              <View style={{ height: 1, backgroundColor: 'rgba(255,255,255,0.08)', marginVertical: 12 }} />
              <TouchableOpacity onPress={() => { setCurrentScreen('pricing'); setDrawerOpen(false); }} style={styles.drawerItem}><View style={styles.drawerIcon}><Ionicons name="pricetags-outline" size={18} color="rgba(255,255,255,0.7)" /></View><Text style={styles.drawerLabel}>Tarifs publics</Text></TouchableOpacity>
              <TouchableOpacity onPress={() => { setCurrentScreen('faq'); setDrawerOpen(false); }} style={styles.drawerItem}><View style={styles.drawerIcon}><Ionicons name="help-circle-outline" size={18} color="rgba(255,255,255,0.7)" /></View><Text style={styles.drawerLabel}>FAQ & Aide</Text></TouchableOpacity>
              <TouchableOpacity onPress={handleLogout} style={styles.drawerItem}><View style={[styles.drawerIcon, { backgroundColor: 'rgba(239,68,68,0.15)' }]}><Ionicons name="log-out-outline" size={18} color={COLORS.error} /></View><Text style={[styles.drawerLabel, { color: COLORS.error }]}>Déconnexion</Text></TouchableOpacity>
              <Text style={{ color: 'rgba(255,255,255,0.25)', fontSize: 11, textAlign: 'center', marginTop: 20 }}>v1.0.0 • UE • RGPD • RLS actif</Text>
            </ScrollView>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );

  // ================= DASHBOARD =================
  const DashboardScreen = () => (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>
      <Text style={{ fontSize: 26, fontWeight: '800', color: COLORS.navy }}>Bonjour, {business.nom.split(' ')[0]} 👋</Text>
      <Text style={{ color: COLORS.text2, marginTop: 4 }}>Voici ce qui se passe aujourd'hui.</Text>

      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginTop: 20 }}>
        <StatCard icon="people" label="Prospects" value={contacts.filter(c => c.status !== 'archive').length} trend={12} color={COLORS.violet} />
        <StatCard icon="document-text" label="Devis en attente" value={devis.filter(d => d.statut === 'envoye').length} trend={-8} color={COLORS.warning} />
        <StatCard icon="calendar" label="RDV aujourd'hui" value={appointments.filter(a => a.date === new Date().toISOString().split('T')[0]).length} trend={5} color={COLORS.blue} />
        <StatCard icon="chatbubbles" label="Msg non lus" value={conversations.filter(c => c.status === 'non_lu').length} trend={25} color={COLORS.success} />
      </View>

      <View style={{ backgroundColor: 'white', borderRadius: 20, padding: 16, marginTop: 20, borderWidth: 1, borderColor: COLORS.border }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Text style={{ fontWeight: '800', color: COLORS.navy }}>Assistant IA — à faire</Text>
          <TouchableOpacity onPress={() => setCurrentScreen('assistant')}><Text style={{ color: COLORS.violet, fontWeight: '700', fontSize: 13 }}>Ouvrir →</Text></TouchableOpacity>
        </View>
        <View style={{ gap: 10, marginTop: 14 }}>
          {[
            { t: 'Marie D. attend une réponse', d: 'Devis coloration - il y a 2h', c: COLORS.error },
            { t: 'Devis mariage à finaliser', d: 'Sophie L. • 510€ TTC • Potentiel', c: COLORS.warning },
            { t: '3 RDV à confirmer', d: "Rappels automatiques si Pro", c: COLORS.blue },
          ].map((it, i) => (
            <View key={i} style={{ flexDirection: 'row', gap: 12, alignItems: 'center', backgroundColor: COLORS.bg, borderRadius: 12, padding: 12 }}>
              <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: it.c }} />
              <View style={{ flex: 1 }}>
                <Text style={{ fontWeight: '600', color: COLORS.text, fontSize: 13 }}>{it.t}</Text>
                <Text style={{ color: COLORS.text3, fontSize: 12 }}>{it.d}</Text>
              </View>
              <Ionicons name="chevron-forward" size={16} color={COLORS.text3} />
            </View>
          ))}
        </View>
      </View>

      <View style={{ flexDirection: 'row', gap: 12, marginTop: 16 }}>
        <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: COLORS.border }}>
          <Text style={{ fontWeight: '700', color: COLORS.navy }}>Consommation IA</Text>
          <View style={{ height: 8, backgroundColor: COLORS.bg2, borderRadius: 8, marginTop: 10, overflow: 'hidden' }}>
            <View style={{ width: `${Math.min(100, (usage.ia / quotas[plan].ia) * 100)}%`, height: '100%', backgroundColor: COLORS.violet, borderRadius: 8 }} />
          </View>
          <Text style={{ fontSize: 12, color: COLORS.text3, marginTop: 6 }}>{usage.ia} / {quotas[plan].ia} messages</Text>
        </View>
        <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: COLORS.border }}>
          <Text style={{ fontWeight: '700', color: COLORS.navy }}>Taux conversion</Text>
          <Text style={{ fontSize: 22, fontWeight: '800', color: COLORS.success, marginTop: 6 }}>62%</Text>
          <Text style={{ fontSize: 12, color: COLORS.text3 }}>Devis → acceptés</Text>
        </View>
      </View>

      <View style={{ flexDirection: 'row', gap: 12, marginTop: 20 }}>
        <TouchableOpacity onPress={() => setCurrentScreen('assistant')} style={{ flex: 1 }}><LinearGradient colors={[COLORS.violet, COLORS.violetDark]} style={{ borderRadius: 14, padding: 14, alignItems: 'center' }}><Ionicons name="sparkles" size={20} color="white" /><Text style={{ color: 'white', fontWeight: '700', marginTop: 6, fontSize: 13 }}>Chat IA</Text></LinearGradient></TouchableOpacity>
        <TouchableOpacity onPress={() => { setNewDevisForm({ contactId: contacts[0]?.id || '', lignes: [{ id: '1', description: '', quantite: 1, prixUnitaire: 0 }], notes: '' }); setShowDevisModal(true); }} style={{ flex: 1, backgroundColor: COLORS.navy, borderRadius: 14, padding: 14, alignItems: 'center' }}><Ionicons name="add" size={20} color="white" /><Text style={{ color: 'white', fontWeight: '700', marginTop: 6, fontSize: 13 }}>Nouveau devis</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => { setNewContactForm({}); setShowContactModal(true); }} style={{ flex: 1, backgroundColor: 'white', borderWidth: 1, borderColor: COLORS.border, borderRadius: 14, padding: 14, alignItems: 'center' }}><Ionicons name="person-add" size={20} color={COLORS.navy} /><Text style={{ color: COLORS.navy, fontWeight: '700', marginTop: 6, fontSize: 13 }}>Contact</Text></TouchableOpacity>
      </View>

      <Text style={{ fontWeight: '800', color: COLORS.navy, marginTop: 24, marginBottom: 12 }}>Derniers devis</Text>
      {devis.slice(0, 3).map(d => {
        const tot = calculateDevisTotal(d.lignes, d.tva);
        return (
          <TouchableOpacity key={d.id} onPress={() => { setSelectedDevis(d); setShowDevisModal(true); }} style={{ backgroundColor: 'white', borderRadius: 14, padding: 14, borderWidth: 1, borderColor: COLORS.border, marginBottom: 10, flexDirection: 'row', justifyContent: 'space-between' }}>
            <View><Text style={{ fontWeight: '700', color: COLORS.navy }}>{d.numero}</Text><Text style={{ color: COLORS.text3, fontSize: 12 }}>{d.contactNom} • {d.createdAt}</Text></View>
            <View style={{ alignItems: 'flex-end' }}><Text style={{ fontWeight: '800', color: COLORS.navy }}>{tot.ttc.toFixed(2)}€ TTC</Text><View style={[styles.statusBadge, { backgroundColor: d.statut === 'accepte' ? COLORS.success + '15' : d.statut === 'envoye' ? COLORS.warning + '15' : COLORS.border }]}><Text style={[styles.statusText, { color: d.statut === 'accepte' ? COLORS.success : d.statut === 'envoye' ? COLORS.warning : COLORS.text3 }]}>{d.statut}</Text></View></View>
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );

  const AssistantScreen = () => (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <View style={{ padding: 16, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: COLORS.border }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <LinearGradient colors={[COLORS.violet, COLORS.violetDark]} style={{ width: 36, height: 36, borderRadius: 10, justifyContent: 'center', alignItems: 'center' }}><Ionicons name="sparkles" size={18} color="white" /></LinearGradient>
          <View style={{ flex: 1 }}><Text style={{ fontWeight: '800', color: COLORS.navy }}>Nexora IA • {business.nom}</Text><Text style={{ fontSize: 12, color: COLORS.text3 }}>Ton {business.ton} • {business.secteur} • Règles actives</Text></View>
          <View style={{ backgroundColor: COLORS.success + '15', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 20 }}><Text style={{ color: COLORS.success, fontSize: 11, fontWeight: '700' }}>● En ligne</Text></View>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 14 }} contentContainerStyle={{ gap: 8 }}>
          {[
            { l: 'Rédiger une réponse', v: 'Peux-tu rédiger une réponse pro pour ce client ?' },
            { l: 'Résumer conversations', v: 'Résume mes conversations récentes' },
            { l: 'Préparer un devis', v: 'Prépare un devis pour coloration + coupe' },
            { l: 'FAQ entreprise', v: 'Quels sont nos horaires et tarifs ?' },
            { l: 'Stats & perf', v: 'Donne mes stats de conversion' },
          ].map(chip => (
            <TouchableOpacity key={chip.l} onPress={() => setChatInput(chip.v)} style={{ backgroundColor: COLORS.bg2, borderRadius: 20, paddingHorizontal: 12, paddingVertical: 8, borderWidth: 1, borderColor: COLORS.violetSoft }}>
              <Text style={{ color: COLORS.violetDark, fontSize: 12, fontWeight: '600' }}>{chip.l}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
      <FlatList
        data={chatMessages}
        keyExtractor={i => i.id}
        contentContainerStyle={{ padding: 16, gap: 12, paddingBottom: 20 }}
        renderItem={({ item }) => (
          <View style={[styles.chatBubble, item.role === 'user' ? styles.chatUser : styles.chatAI]}>
            {item.role === 'assistant' && <View style={{ flexDirection: 'row', gap: 8, marginBottom: 6 }}><LinearGradient colors={[COLORS.violet, COLORS.violetDark]} style={{ width: 20, height: 20, borderRadius: 6, justifyContent: 'center', alignItems: 'center' }}><Text style={{ color: 'white', fontSize: 10, fontWeight: '900' }}>N</Text></LinearGradient><Text style={{ fontWeight: '700', fontSize: 12, color: COLORS.violetDark }}>Nexora</Text></View>}
            <Text style={[styles.chatText, item.role === 'user' && { color: 'white' }]}>{item.content}</Text>
            <Text style={[styles.chatTime, item.role === 'user' && { color: 'rgba(255,255,255,0.7)' }]}>{new Date(item.timestamp).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</Text>
          </View>
        )}
      />
      {isTyping && <View style={{ paddingHorizontal: 16, paddingBottom: 8 }}><View style={{ backgroundColor: 'white', borderRadius: 14, padding: 12, alignSelf: 'flex-start', borderWidth: 1, borderColor: COLORS.border }}><Text style={{ color: COLORS.text3, fontSize: 12 }}>Nexora écrit... • Config: {business.ton}</Text></View></View>}
      <View style={{ flexDirection: 'row', gap: 8, padding: 12, backgroundColor: 'white', borderTopWidth: 1, borderTopColor: COLORS.border }}>
        <TextInput value={chatInput} onChangeText={setChatInput} placeholder="Demande une réponse, un devis, un résumé..." style={{ flex: 1, backgroundColor: COLORS.bg, borderRadius: 24, paddingHorizontal: 16, paddingVertical: 12, borderWidth: 1, borderColor: COLORS.border }} multiline />
        <TouchableOpacity onPress={handleSendChat} style={{ width: 48, height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center' }}><LinearGradient colors={[COLORS.violet, COLORS.violetDark]} style={[StyleSheet.absoluteFill, { borderRadius: 24 }]} /><Ionicons name="send" size={18} color="white" /></TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );

  const ConfigScreen = () => (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>
      <Text style={{ fontSize: 22, fontWeight: '800', color: COLORS.navy }}>Configuration IA</Text>
      <Text style={{ color: COLORS.text2, marginTop: 4, fontSize: 13 }}>Isolation stricte : entreprise_id = {business.id} • RLS activé</Text>

      <View style={styles.configSection}>
        <Text style={styles.configTitle}>Entreprise</Text>
        <Text style={styles.inputLabel}>Nom *</Text><TextInput value={business.nom} onChangeText={t => setBusiness({ ...business, nom: t })} style={styles.inputBox} />
        <Text style={styles.inputLabel}>Secteur</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 6 }}>
          {['Coiffeur', 'Garage', 'Artisan', 'Freelance', 'Agence'].map(s => (
            <TouchableOpacity key={s} onPress={() => setBusiness({ ...business, secteur: s })} style={[styles.secteurPill, business.secteur === s && styles.secteurPillActive]}><Text style={[styles.secteurText, business.secteur === s && styles.secteurTextActive]}>{s}</Text></TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.configSection}>
        <Text style={styles.configTitle}>Services & tarifs</Text>
        {business.services.map((s, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8, marginBottom: 8 }}>
            <TextInput value={s.nom} onChangeText={t => { const ns = [...business.services]; ns[i].nom = t; setBusiness({ ...business, services: ns }); }} placeholder="Service" style={[styles.inputBox, { flex: 2 }]} />
            <TextInput value={String(s.prix)} onChangeText={t => { const ns = [...business.services]; ns[i].prix = parseInt(t) || 0; setBusiness({ ...business, services: ns }); }} placeholder="€" keyboardType="numeric" style={[styles.inputBox, { flex: 1 }]} />
          </View>
        ))}
        <TouchableOpacity onPress={() => setBusiness({ ...business, services: [...business.services, { nom: '', prix: 0, duree: '30min' }] })}><Text style={{ color: COLORS.violet, fontWeight: '700', marginTop: 8 }}>+ Ajouter service</Text></TouchableOpacity>
        <Text style={styles.inputLabel}>Descriptif tarifs</Text><TextInput value={business.tarifs} onChangeText={t => setBusiness({ ...business, tarifs: t })} style={[styles.inputBox, { height: 60 }]} multiline />
        <Text style={styles.inputLabel}>Horaires</Text><TextInput value={business.horaires} onChangeText={t => setBusiness({ ...business, horaires: t })} style={styles.inputBox} />
      </View>

      <View style={styles.configSection}>
        <Text style={styles.configTitle}>Coordonnées</Text>
        <TextInput value={business.telephone} onChangeText={t => setBusiness({ ...business, telephone: t })} placeholder="Téléphone" style={styles.inputBox} />
        <TextInput value={business.email} onChangeText={t => setBusiness({ ...business, email: t })} placeholder="Email" style={[styles.inputBox, { marginTop: 8 }]} />
        <TextInput value={business.adresse} onChangeText={t => setBusiness({ ...business, adresse: t })} placeholder="Adresse" style={[styles.inputBox, { marginTop: 8 }]} />
      </View>

      <View style={styles.configSection}>
        <Text style={styles.configTitle}>IA — Ton & règles</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {['professionnel', 'amical', 'formel', 'detendu'].map(t => (
            <TouchableOpacity key={t} onPress={() => setBusiness({ ...business, ton: t as any })} style={[styles.secteurPill, business.ton === t && styles.secteurPillActive]}><Text style={[styles.secteurText, business.ton === t && styles.secteurTextActive]}>{t}</Text></TouchableOpacity>
          ))}
        </View>
        <Text style={styles.inputLabel}>Règles de réponse (prompt système)</Text><TextInput value={business.regles} onChangeText={t => setBusiness({ ...business, regles: t })} multiline style={[styles.inputBox, { height: 80 }]} />
        <View style={{ backgroundColor: COLORS.violetSoft, borderRadius: 12, padding: 12, marginTop: 12 }}><Text style={{ fontSize: 12, color: COLORS.violetDark }}>💡 Le prompt final : "Tu es assistant de {business.nom} ({business.secteur}). Ton : {business.ton}. Règles : {business.regles}. Services : {business.services.map(s => `${s.nom} ${s.prix}€`).join(', ')}. Ne jamais halluciner prix/horaires."</Text></View>
      </View>

      <PremiumButton title="Sauvegarder la configuration" onPress={() => { persist('nexora_business', business); alert('Configuration sauvegardée • Isolation RLS OK'); }} icon="save" />
      <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 12, marginTop: 12, borderWidth: 1, borderColor: COLORS.border }}><Text style={{ fontSize: 11, color: COLORS.text3 }}>🔐 Supabase RLS : CREATE POLICY ... USING (entreprise_id = auth.jwt()→entreprise_id). Validation Zod côté serveur. Clés API jamais exposées.</Text></View>
    </ScrollView>
  );

  const CRMScreen = () => {
    const filtered = contacts.filter(c => (c.nom + c.prenom + c.email).toLowerCase().includes(searchQuery.toLowerCase()));
    return (
      <View style={{ flex: 1 }}>
        <View style={{ padding: 16, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: COLORS.border }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={{ fontSize: 20, fontWeight: '800', color: COLORS.navy }}>CRM • {contacts.length}</Text>
            <TouchableOpacity onPress={() => { setNewContactForm({}); setShowContactModal(true); }} style={{ backgroundColor: COLORS.navy, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="add" size={16} color="white" /><Text style={{ color: 'white', fontWeight: '700', fontSize: 12 }}>Nouveau</Text></TouchableOpacity>
          </View>
          <View style={[styles.inputWrapper, { marginTop: 12 }]}><Ionicons name="search" size={16} color={COLORS.text3} /><TextInput value={searchQuery} onChangeText={setSearchQuery} placeholder="Rechercher nom, email..." style={styles.input} /></View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, marginTop: 12 }}>
            {['Tous', 'nouveau', 'prospect', 'client', 'archive'].map(s => (
              <TouchableOpacity key={s} onPress={() => setSearchQuery(s === 'Tous' ? '' : s)} style={{ backgroundColor: searchQuery === s || (s === 'Tous' && searchQuery === '') ? COLORS.navy : COLORS.bg2, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 }}><Text style={{ color: searchQuery === s || (s === 'Tous' && searchQuery === '') ? 'white' : COLORS.text2, fontSize: 12, fontWeight: '600' }}>{s}</Text></TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        <FlatList
          data={filtered}
          keyExtractor={i => i.id}
          contentContainerStyle={{ padding: 16, gap: 10, paddingBottom: 100 }}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => { setSelectedContact(item); setNewContactForm(item); setShowContactModal(true); }} style={{ backgroundColor: 'white', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: COLORS.border }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center' }}>
                  <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: COLORS.violetSoft, justifyContent: 'center', alignItems: 'center' }}><Text style={{ fontWeight: '800', color: COLORS.violet }}>{item.prenom[0]}{item.nom[0]}</Text></View>
                  <View><Text style={{ fontWeight: '700', color: COLORS.navy }}>{item.prenom} {item.nom}</Text><Text style={{ fontSize: 12, color: COLORS.text3 }}>{item.email}</Text></View>
                </View>
                <View style={[styles.statusBadge, { backgroundColor: item.status === 'client' ? COLORS.success + '15' : item.status === 'prospect' ? COLORS.warning + '15' : COLORS.bg2 }]}><Text style={[styles.statusText, { color: item.status === 'client' ? COLORS.success : item.status === 'prospect' ? COLORS.warning : COLORS.text3 }]}>{item.status}</Text></View>
              </View>
              {item.notes ? <Text style={{ color: COLORS.text2, fontSize: 12, marginTop: 10, backgroundColor: COLORS.bg, padding: 8, borderRadius: 8 }}>{item.notes}</Text> : null}
              <View style={{ flexDirection: 'row', gap: 12, marginTop: 10 }}><View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}><Ionicons name="call-outline" size={12} color={COLORS.text3} /><Text style={{ fontSize: 11, color: COLORS.text3 }}>{item.telephone}</Text></View><View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}><Ionicons name="time-outline" size={12} color={COLORS.text3} /><Text style={{ fontSize: 11, color: COLORS.text3 }}>{item.createdAt} • {item.source}</Text></View></View>
            </TouchableOpacity>
          )}
        />
      </View>
    );
  };

  const DevisScreen = () => (
    <View style={{ flex: 1 }}>
      <View style={{ padding: 16, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: COLORS.border }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Text style={{ fontSize: 20, fontWeight: '800', color: COLORS.navy }}>Devis • {devis.length}</Text>
          <TouchableOpacity onPress={() => { setNewDevisForm({ contactId: contacts[0]?.id || '', lignes: [{ id: '1', description: business.services[0]?.nom || '', quantite: 1, prixUnitaire: business.services[0]?.prix || 0 }], notes: '' }); setShowDevisModal(true); }} style={{ backgroundColor: COLORS.navy, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="add" size={16} color="white" /><Text style={{ color: 'white', fontWeight: '700', fontSize: 12 }}>Nouveau devis</Text></TouchableOpacity>
        </View>
        <View style={{ flexDirection: 'row', gap: 8, marginTop: 12 }}>
          {[{ k: 'Tous', v: devis.length }, { k: 'brouillon', v: devis.filter(d => d.statut === 'brouillon').length }, { k: 'envoye', v: devis.filter(d => d.statut === 'envoye').length }, { k: 'accepte', v: devis.filter(d => d.statut === 'accepte').length }].map(f => (
            <View key={f.k} style={{ backgroundColor: COLORS.bg2, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 6 }}><Text style={{ fontSize: 12, color: COLORS.text2, fontWeight: '600' }}>{f.k} {f.v}</Text></View>
          ))}
        </View>
      </View>
      <FlatList
        data={devis}
        keyExtractor={i => i.id}
        contentContainerStyle={{ padding: 16, gap: 12, paddingBottom: 100 }}
        renderItem={({ item }) => {
          const tot = calculateDevisTotal(item.lignes, item.tva);
          return (
            <TouchableOpacity onPress={() => { setSelectedDevis(item); setShowDevisModal(true); }} style={{ backgroundColor: 'white', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: COLORS.border }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={{ fontWeight: '800', color: COLORS.navy }}>{item.numero}</Text>
                <View style={[styles.statusBadge, { backgroundColor: item.statut === 'accepte' ? COLORS.success + '15' : item.statut === 'envoye' ? COLORS.warning + '15' : item.statut === 'refuse' ? COLORS.error + '15' : COLORS.bg2 }]}><Text style={[styles.statusText, { color: item.statut === 'accepte' ? COLORS.success : item.statut === 'envoye' ? COLORS.warning : COLORS.text3 }]}>{item.statut.toUpperCase()}</Text></View>
              </View>
              <Text style={{ color: COLORS.text2, marginTop: 4 }}>{item.contactNom} • {item.createdAt} • Valide jusqu'au {item.validite}</Text>
              <View style={{ marginTop: 10, gap: 4 }}>
                {item.lignes.slice(0, 2).map(l => (<Text key={l.id} style={{ fontSize: 12, color: COLORS.text3 }}>• {l.description} x{l.quantite} — {l.prixUnitaire}€</Text>))}
                {item.lignes.length > 2 && <Text style={{ fontSize: 11, color: COLORS.violet }}>+{item.lignes.length - 2} lignes...</Text>}
              </View>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 12, borderTopWidth: 1, borderTopColor: COLORS.bg2, paddingTop: 10 }}>
                <Text style={{ color: COLORS.text3, fontSize: 12 }}>HT {tot.ht.toFixed(2)}€ • TVA {tot.tva.toFixed(2)}€</Text>
                <Text style={{ fontWeight: '800', color: COLORS.navy }}>{tot.ttc.toFixed(2)}€ TTC</Text>
              </View>
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );

  const ConversationsScreen = () => (
    <View style={{ flex: 1 }}>
      <View style={{ padding: 16, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: COLORS.border }}>
        <Text style={{ fontSize: 20, fontWeight: '800', color: COLORS.navy }}>Conversations</Text>
        <Text style={{ fontSize: 12, color: COLORS.text3 }}>{conversations.filter(c => c.status === 'non_lu').length} non lus • IA draft disponible</Text>
      </View>
      <FlatList
        data={conversations}
        keyExtractor={i => i.id}
        contentContainerStyle={{ padding: 16, gap: 10, paddingBottom: 100 }}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => { setSelectedConv(item); setShowConvModal(true); }} style={{ backgroundColor: 'white', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: item.status === 'non_lu' ? COLORS.violetSoft : COLORS.border, flexDirection: 'row', gap: 12 }}>
            <View style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: item.status === 'non_lu' ? COLORS.violet : COLORS.bg2, justifyContent: 'center', alignItems: 'center' }}><Text style={{ fontWeight: '800', color: item.status === 'non_lu' ? 'white' : COLORS.text3 }}>{item.contactNom.split(' ').map(n => n[0]).join('').slice(0, 2)}</Text></View>
            <View style={{ flex: 1 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={{ fontWeight: item.status === 'non_lu' ? '800' : '600', color: COLORS.navy }}>{item.contactNom}</Text><Text style={{ fontSize: 11, color: COLORS.text3 }}>{new Date(item.updatedAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</Text></View>
              <Text numberOfLines={2} style={{ color: COLORS.text2, fontSize: 13, marginTop: 2 }}>{item.preview}</Text>
              <View style={{ flexDirection: 'row', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>{item.tags.map(t => (<View key={t} style={{ backgroundColor: COLORS.bg2, borderRadius: 12, paddingHorizontal: 8, paddingVertical: 3 }}><Text style={{ fontSize: 10, color: COLORS.text3, fontWeight: '600' }}>{t}</Text></View>))}</View>
            </View>
            {item.status === 'non_lu' && <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: COLORS.violet, marginTop: 6 }} />}
          </TouchableOpacity>
        )}
      />
    </View>
  );

  const AppointmentsScreen = () => (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text style={{ fontSize: 20, fontWeight: '800', color: COLORS.navy }}>Rendez-vous</Text>
        <TouchableOpacity onPress={() => setShowApptModal(true)} style={{ backgroundColor: COLORS.navy, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 8 }}><Text style={{ color: 'white', fontWeight: '700', fontSize: 12 }}>+ Créneau</Text></TouchableOpacity>
      </View>
      {/* Mini Calendar */}
      <View style={{ backgroundColor: 'white', borderRadius: 16, padding: 14, marginTop: 16, borderWidth: 1, borderColor: COLORS.border }}>
        <Text style={{ fontWeight: '700', color: COLORS.navy }}>Octobre 2026</Text>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 12 }}>
          {['L','M','M','J','V','S','D'].map(d => (<Text key={d} style={{ width: 32, textAlign: 'center', fontSize: 11, color: COLORS.text3, fontWeight: '700' }}>{d}</Text>))}
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 }}>
          {Array.from({ length: 31 }).map((_, i) => {
            const day = i + 1;
            const hasAppt = appointments.some(a => parseInt(a.date.split('-')[2]) === day);
            const isToday = day === 25;
            return (
              <View key={day} style={{ width: `${100 / 7}%`, alignItems: 'center', paddingVertical: 6 }}>
                <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: isToday ? COLORS.navy : hasAppt ? COLORS.violetSoft : 'transparent', justifyContent: 'center', alignItems: 'center', borderWidth: hasAppt && !isToday ? 1 : 0, borderColor: COLORS.violet }}>
                  <Text style={{ fontSize: 12, fontWeight: hasAppt || isToday ? '800' : '500', color: isToday ? 'white' : hasAppt ? COLORS.violetDark : COLORS.text2 }}>{day}</Text>
                </View>
              </View>
            );
          })}
        </View>
      </View>
      <Text style={{ fontWeight: '700', color: COLORS.navy, marginTop: 20, marginBottom: 10 }}>Aujourd'hui & prochains</Text>
      {appointments.map(ap => (
        <View key={ap.id} style={{ backgroundColor: 'white', borderRadius: 14, padding: 14, borderWidth: 1, borderColor: COLORS.border, marginBottom: 10, flexDirection: 'row', gap: 12 }}>
          <View style={{ width: 56, backgroundColor: COLORS.bg2, borderRadius: 12, justifyContent: 'center', alignItems: 'center', paddingVertical: 8 }}><Text style={{ fontWeight: '800', color: COLORS.navy, fontSize: 12 }}>{ap.date.split('-')[2]}/{ap.date.split('-')[1]}</Text><Text style={{ fontWeight: '800', color: COLORS.violet, fontSize: 14 }}>{ap.heure}</Text></View>
          <View style={{ flex: 1 }}><Text style={{ fontWeight: '700', color: COLORS.navy }}>{ap.titre}</Text><Text style={{ fontSize: 12, color: COLORS.text3 }}>{ap.duree}min • {ap.contactNom}</Text>{ap.notes ? <Text style={{ fontSize: 11, color: COLORS.text2, marginTop: 4, backgroundColor: COLORS.bg, padding: 6, borderRadius: 6 }}>{ap.notes}</Text> : null}</View>
          <View style={[styles.statusBadge, { backgroundColor: ap.statut === 'confirme' ? COLORS.success + '15' : COLORS.warning + '15', height: 22 }]}><Text style={[styles.statusText, { color: ap.statut === 'confirme' ? COLORS.success : COLORS.warning }]}>{ap.statut}</Text></View>
        </View>
      ))}
      <View style={{ backgroundColor: COLORS.violetSoft, borderRadius: 12, padding: 12, marginTop: 12 }}><Text style={{ fontSize: 12, color: COLORS.violetDark, fontWeight: '600' }}>🔔 Rappel auto J-1 activé (Pro). SMS via provider configuré côté serveur. Pas de simulation — si clé manquante, message clair dans logs.</Text></View>
    </ScrollView>
  );

  const AutomationsScreen = () => (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text style={{ fontSize: 20, fontWeight: '800', color: COLORS.navy }}>Automatisations</Text>
        {plan === 'starter' && <View style={{ backgroundColor: COLORS.warning + '15', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 }}><Text style={{ color: COLORS.warning, fontSize: 11, fontWeight: '700' }}>PRO requis</Text></View>}
      </View>
      <Text style={{ color: COLORS.text3, fontSize: 12, marginTop: 4 }}>Tâches de suivi, rappels, relances auto. Quotas vérifiés serveur.</Text>
      <View style={{ gap: 12, marginTop: 20 }}>
        {automations.map(auto => (
          <View key={auto.id} style={{ backgroundColor: 'white', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: COLORS.border, opacity: plan === 'starter' ? 0.6 : 1 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center', flex: 1 }}>
                <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: auto.actif ? COLORS.violetSoft : COLORS.bg2, justifyContent: 'center', alignItems: 'center' }}><Ionicons name="flash" size={18} color={auto.actif ? COLORS.violet : COLORS.text3} /></View>
                <View style={{ flex: 1 }}><Text style={{ fontWeight: '700', color: COLORS.navy }}>{auto.nom}</Text><Text style={{ fontSize: 11, color: COLORS.text3 }}>{auto.declencheur} → {auto.action}</Text></View>
              </View>
              <Switch value={auto.actif} onValueChange={v => { if (plan === 'starter') { alert('Fonctionnalité Pro : passez à Pro pour activer les automatisations'); return; } setAutomations(prev => prev.map(a => a.id === auto.id ? { ...a, actif: v } : a)); }} trackColor={{ false: COLORS.border, true: COLORS.violetSoft }} thumbColor={auto.actif ? COLORS.violet : COLORS.white} disabled={plan === 'starter'} />
            </View>
            <Text style={{ fontSize: 12, color: COLORS.text2, marginTop: 10 }}>{auto.description}</Text>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 }}>
              <Text style={{ fontSize: 11, color: COLORS.text3 }}>{auto.executions} exécutions ce mois</Text>
              <Text style={{ fontSize: 11, color: auto.actif ? COLORS.success : COLORS.text3, fontWeight: '700' }}>{auto.actif ? '● Actif' : '○ Inactif'}</Text>
            </View>
          </View>
        ))}
      </View>
      <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 12, marginTop: 16, borderWidth: 1, borderColor: COLORS.border, borderStyle: 'dashed' }}>
        <Text style={{ fontWeight: '700', color: COLORS.navy, fontSize: 13 }}>+ Créer une automatisation personnalisée</Text>
        <Text style={{ fontSize: 11, color: COLORS.text3, marginTop: 4 }}>Déclencheur → Action → Canal (Email/SMS). Validation serveur avec quotas {quotas[plan].ia}.</Text>
      </View>
    </ScrollView>
  );

  const StatsScreen = () => (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>
      <Text style={{ fontSize: 20, fontWeight: '800', color: COLORS.navy }}>Statistiques</Text>
      <View style={{ flexDirection: 'row', gap: 10, marginTop: 16 }}>
        <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: COLORS.border }}><Text style={{ fontSize: 12, color: COLORS.text3 }}>Prospects</Text><Text style={{ fontSize: 24, fontWeight: '800', color: COLORS.navy, marginTop: 4 }}>38</Text><View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 }}><Ionicons name="trending-up" size={14} color={COLORS.success} /><Text style={{ fontSize: 12, color: COLORS.success, fontWeight: '700' }}>+34% vs Sept</Text></View></View>
        <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: COLORS.border }}><Text style={{ fontSize: 12, color: COLORS.text3 }}>Conversions</Text><Text style={{ fontSize: 24, fontWeight: '800', color: COLORS.navy, marginTop: 4 }}>62%</Text><Text style={{ fontSize: 11, color: COLORS.text3, marginTop: 4 }}>8/13 devis acceptés</Text></View>
      </View>

      <View style={{ backgroundColor: 'white', borderRadius: 16, padding: 16, marginTop: 16, borderWidth: 1, borderColor: COLORS.border }}>
        <Text style={{ fontWeight: '700', color: COLORS.navy }}>Prospects par semaine</Text>
        <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 8, marginTop: 16, height: 120 }}>
          {[4, 7, 5, 9, 12, 8, 6].map((v, i) => (
            <View key={i} style={{ flex: 1, alignItems: 'center', gap: 6 }}>
              <View style={{ width: '100%', backgroundColor: i === 4 ? COLORS.violet : COLORS.violetSoft, height: v * 10, borderRadius: 6 }} />
              <Text style={{ fontSize: 10, color: COLORS.text3 }}>S{i + 1}</Text>
            </View>
          ))}
        </View>
      </View>

      <View style={{ backgroundColor: 'white', borderRadius: 16, padding: 16, marginTop: 16, borderWidth: 1, borderColor: COLORS.border }}>
        <Text style={{ fontWeight: '700', color: COLORS.navy }}>Répartition devis</Text>
        <View style={{ gap: 10, marginTop: 12 }}>
          {[
            { label: 'Acceptés', count: 5, color: COLORS.success, pct: 62 },
            { label: 'Envoyés', count: 2, color: COLORS.warning, pct: 25 },
            { label: 'Brouillons', count: 1, color: COLORS.text3, pct: 13 },
          ].map(r => (
            <View key={r.label} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: r.color }} />
              <Text style={{ flex: 1, color: COLORS.text2, fontSize: 13 }}>{r.label} ({r.count})</Text>
              <View style={{ width: 80, height: 6, backgroundColor: COLORS.bg2, borderRadius: 3 }}><View style={{ width: `${r.pct}%`, height: '100%', backgroundColor: r.color, borderRadius: 3 }} /></View>
              <Text style={{ fontSize: 12, fontWeight: '700', color: COLORS.navy, width: 30 }}>{r.pct}%</Text>
            </View>
          ))}
        </View>
      </View>

      <View style={{ backgroundColor: COLORS.navy, borderRadius: 16, padding: 16, marginTop: 16 }}>
        <Text style={{ color: 'white', fontWeight: '700' }}>Consommation IA • {plan.toUpperCase()}</Text>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 12 }}>
          <View><Text style={{ color: 'rgba(255,255,255,0.6)', fontSize: 12 }}>Utilisé</Text><Text style={{ color: 'white', fontWeight: '800', fontSize: 18 }}>{usage.ia}</Text></View>
          <View><Text style={{ color: 'rgba(255,255,255,0.6)', fontSize: 12 }}>Quota</Text><Text style={{ color: 'white', fontWeight: '800', fontSize: 18 }}>{quotas[plan].ia}</Text></View>
          <View><Text style={{ color: 'rgba(255,255,255,0.6)', fontSize: 12 }}>Restant</Text><Text style={{ color: COLORS.violetBright, fontWeight: '800', fontSize: 18 }}>{quotas[plan].ia - usage.ia}</Text></View>
        </View>
        <View style={{ height: 8, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 8, marginTop: 14 }}><View style={{ width: `${(usage.ia / quotas[plan].ia) * 100}%`, height: '100%', backgroundColor: COLORS.violetBright, borderRadius: 8 }} /></View>
        <Text style={{ color: 'rgba(255,255,255,0.5)', fontSize: 11, marginTop: 8 }}>Quotas appliqués côté serveur. Au-delà, passage au palier supérieur ou facturation à l'usage.</Text>
      </View>
    </ScrollView>
  );

  const SubscriptionScreen = () => (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>
      <Text style={{ fontSize: 20, fontWeight: '800', color: COLORS.navy }}>Abonnement</Text>
      <View style={{ backgroundColor: 'white', borderRadius: 16, padding: 16, marginTop: 16, borderWidth: 1, borderColor: COLORS.violetSoft }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <View><Text style={{ fontWeight: '800', color: COLORS.navy, fontSize: 16 }}>Plan {plan.toUpperCase()}</Text><Text style={{ color: COLORS.text3, fontSize: 12 }}>{planPrices[plan]}€/mois HT • Renouvellement 25 nov 2026</Text></View>
          <LinearGradient colors={[COLORS.violet, COLORS.violetDark]} style={{ paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 }}><Text style={{ color: 'white', fontWeight: '700', fontSize: 12 }}>Actif</Text></LinearGradient>
        </View>
        <View style={{ flexDirection: 'row', gap: 10, marginTop: 14 }}>
          <View style={{ flex: 1, backgroundColor: COLORS.bg, borderRadius: 12, padding: 10 }}><Text style={{ fontSize: 11, color: COLORS.text3 }}>IA</Text><Text style={{ fontWeight: '800', color: COLORS.navy }}>{usage.ia}/{quotas[plan].ia}</Text><View style={{ height: 4, backgroundColor: COLORS.border, borderRadius: 2, marginTop: 6 }}><View style={{ width: `${(usage.ia / quotas[plan].ia) * 100}%`, height: '100%', backgroundColor: COLORS.violet, borderRadius: 2 }} /></View></View>
          <View style={{ flex: 1, backgroundColor: COLORS.bg, borderRadius: 12, padding: 10 }}><Text style={{ fontSize: 11, color: COLORS.text3 }}>Contacts</Text><Text style={{ fontWeight: '800', color: COLORS.navy }}>{contacts.length}/{quotas[plan].contacts}</Text></View>
          <View style={{ flex: 1, backgroundColor: COLORS.bg, borderRadius: 12, padding: 10 }}><Text style={{ fontSize: 11, color: COLORS.text3 }}>Devis</Text><Text style={{ fontWeight: '800', color: COLORS.navy }}>{devis.length}/{quotas[plan].devis}</Text></View>
        </View>
      </View>

      <Text style={{ fontWeight: '800', color: COLORS.navy, marginTop: 24, marginBottom: 12 }}>Changer de forfait</Text>
      {(Object.keys(planPrices) as PlanType[]).map(k => (
        <View key={k} style={{ backgroundColor: 'white', borderRadius: 14, padding: 14, borderWidth: 1, borderColor: plan === k ? COLORS.violet : COLORS.border, marginBottom: 10 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={{ fontWeight: '800', color: COLORS.navy }}>{k.toUpperCase()} • {planPrices[k]}€/mois</Text>
            {plan === k ? <View style={{ backgroundColor: COLORS.success + '15', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10 }}><Text style={{ color: COLORS.success, fontSize: 11, fontWeight: '700' }}>Actuel</Text></View> : <TouchableOpacity onPress={() => setPlan(k)} style={{ backgroundColor: COLORS.navy, paddingHorizontal: 14, paddingVertical: 6, borderRadius: 10 }}><Text style={{ color: 'white', fontWeight: '700', fontSize: 12 }}>Choisir</Text></TouchableOpacity>}
          </View>
          <Text style={{ fontSize: 12, color: COLORS.text3, marginTop: 6 }}>{quotas[k].ia} IA • {quotas[k].contacts} contacts • {quotas[k].devis} devis • {quotas[k].auto ? 'Auto' : 'Sans auto'}</Text>
        </View>
      ))}

      <View style={{ backgroundColor: 'white', borderRadius: 14, padding: 14, marginTop: 16, borderWidth: 1, borderColor: COLORS.border }}>
        <Text style={{ fontWeight: '700', color: COLORS.navy }}>Paiement sécurisé</Text>
        <Text style={{ fontSize: 12, color: COLORS.text2, marginTop: 6 }}>Stripe • Webhooks sécurisés • Facture auto • Annulation en 1 clic avant renouvellement. Aucune simulation : si webhook échoue, logs + email admin.</Text>
        <TouchableOpacity style={{ marginTop: 12, backgroundColor: COLORS.bg2, borderRadius: 10, padding: 12, alignItems: 'center' }}><Text style={{ fontWeight: '700', color: COLORS.navy, fontSize: 12 }}>Gérer facturation & annuler</Text></TouchableOpacity>
      </View>

      <View style={{ backgroundColor: COLORS.violetSoft, borderRadius: 12, padding: 12, marginTop: 16 }}><Text style={{ fontSize: 11, color: COLORS.violetDark, lineHeight: 16 }}>🔐 Sécurité paiement : STRIPE_SECRET_KEY et WEBHOOK_SECRET uniquement côté serveur (Edge Function). Validation signature Stripe. Pas de clé exposée navigateur. RLS : user ne voit que son entreprise_id.</Text></View>
    </ScrollView>
  );

  const AdminScreen = () => (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>
      <Text style={{ fontSize: 20, fontWeight: '800', color: COLORS.navy }}>Administration</Text>
      <Text style={{ fontSize: 12, color: COLORS.text3, marginTop: 4 }}>Réservé super-admin • Logs erreurs & gestion plans</Text>

      <View style={{ backgroundColor: COLORS.navy, borderRadius: 16, padding: 16, marginTop: 16 }}>
        <Text style={{ color: 'white', fontWeight: '700' }}>Multi-tenant • Isolation</Text>
        <Text style={{ color: 'rgba(255,255,255,0.6)', fontSize: 12, marginTop: 6, lineHeight: 16 }}>Chaque ligne PG contient entreprise_id. RLS : USING (entreprise_id = jwt.entreprise_id). JWT signé serveur. Aucun accès cross-tenant possible. Test d'intrusion mensuel.</Text>
        <View style={{ flexDirection: 'row', gap: 8, marginTop: 12 }}>
          <View style={{ backgroundColor: 'rgba(255,255,255,0.1)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 }}><Text style={{ color: 'white', fontSize: 11 }}>RLS actif</Text></View>
          <View style={{ backgroundColor: COLORS.success + '30', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 }}><Text style={{ color: COLORS.success, fontSize: 11 }}>● API protégée</Text></View>
        </View>
      </View>

      <View style={styles.configSection}>
        <Text style={styles.configTitle}>Gestion plans & quotas</Text>
        {(Object.keys(planPrices) as PlanType[]).map(k => (
          <View key={k} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 8 }}>
            <Text style={{ width: 80, fontWeight: '700', color: COLORS.navy }}>{k}</Text>
            <TextInput value={String(planPrices[k])} onChangeText={t => setPlanPrices({ ...planPrices, [k]: parseInt(t) || 0 })} style={[styles.inputBox, { flex: 1 }]} keyboardType="numeric" />
            <Text style={{ color: COLORS.text3 }}>€</Text>
          </View>
        ))}
        <PremiumButton title="Sauvegarder les tarifs" onPress={() => alert('Tarifs sauvegardés • Migration DB : ALTER TABLE plans ...')} small />
      </View>

      <View style={styles.configSection}>
        <Text style={styles.configTitle}>Journaux erreurs (mock)</Text>
        {[
          { time: '14:32', level: 'WARN', msg: 'IA quota 80% — entreprise biz_1' },
          { time: '13:10', level: 'INFO', msg: 'Webhook Stripe reçu — sub_pro_123' },
          { time: '11:45', level: 'ERROR', msg: 'OPENAI_API_KEY manquante — voir .env.example' },
        ].map((log, i) => (
          <View key={i} style={{ backgroundColor: COLORS.bg, borderRadius: 8, padding: 10, marginTop: 8, flexDirection: 'row', gap: 8 }}>
            <Text style={{ fontSize: 11, color: COLORS.text3 }}>{log.time}</Text>
            <Text style={{ fontSize: 11, fontWeight: '700', color: log.level === 'ERROR' ? COLORS.error : log.level === 'WARN' ? COLORS.warning : COLORS.blue }}>{log.level}</Text>
            <Text style={{ fontSize: 11, color: COLORS.text2, flex: 1 }}>{log.msg}</Text>
          </View>
        ))}
        <View style={{ backgroundColor: COLORS.violetSoft, borderRadius: 8, padding: 10, marginTop: 12 }}>
          <Text style={{ fontSize: 11, color: COLORS.violetDark, fontWeight: '700' }}>.env.example sans secrets :</Text>
          <Text style={{ fontSize: 10, color: COLORS.violetDark, marginTop: 4, fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace' }}>
            SUPABASE_URL=...{'\n'}SUPABASE_ANON_KEY=...{'\n'}SUPABASE_SERVICE_ROLE_KEY= [SERVEUR]{'\n'}OPENAI_API_KEY= [SERVEUR]{'\n'}STRIPE_SECRET= [SERVEUR]{'\n'}STRIPE_WEBHOOK_SECRET= [SERVEUR]
          </Text>
        </View>
      </View>

      <View style={styles.configSection}>
        <Text style={styles.configTitle}>Utilisateurs (RLS test)</Text>
        <Text style={{ fontSize: 12, color: COLORS.text2 }}>Actuellement 1 entreprise isolée. Pour ajouter un test multi-tenant : créer 2 utilisateurs avec entreprise_id différents, vérifier qu'ils ne voient pas les données de l'autre (SELECT * doit filtrer).</Text>
      </View>
    </ScrollView>
  );

  // ================= MODALS =================
  const ContactModal = () => (
    <Modal visible={showContactModal} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setShowContactModal(false)}>
      <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.bg }}>
        <View style={styles.modalHeader}>
          <TouchableOpacity onPress={() => setShowContactModal(false)}><Text style={{ color: COLORS.violet, fontWeight: '700' }}>Annuler</Text></TouchableOpacity>
          <Text style={{ fontWeight: '800', color: COLORS.navy }}>{selectedContact ? 'Modifier' : 'Nouveau contact'}</Text>
          <TouchableOpacity onPress={selectedContact ? () => { const upd = contacts.map(c => c.id === selectedContact.id ? { ...c, ...newContactForm } as CRMContact : c); setContacts(upd); persist('nexora_contacts', upd); setShowContactModal(false); setSelectedContact(null); } : handleCreateContact}><Text style={{ color: COLORS.violet, fontWeight: '700' }}>Enregistrer</Text></TouchableOpacity>
        </View>
        <ScrollView contentContainerStyle={{ padding: 16, gap: 12 }}>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}><Text style={styles.inputLabel}>Prénom</Text><TextInput value={newContactForm.prenom as string} onChangeText={t => setNewContactForm({ ...newContactForm, prenom: t })} placeholder="Prénom" style={styles.inputBox} /></View>
            <View style={{ flex: 1 }}><Text style={styles.inputLabel}>Nom</Text><TextInput value={newContactForm.nom as string} onChangeText={t => setNewContactForm({ ...newContactForm, nom: t })} placeholder="Nom" style={styles.inputBox} /></View>
          </View>
          <Text style={styles.inputLabel}>Email</Text><TextInput value={newContactForm.email as string} onChangeText={t => setNewContactForm({ ...newContactForm, email: t })} placeholder="email@exemple.fr" style={styles.inputBox} keyboardType="email-address" />
          <Text style={styles.inputLabel}>Téléphone</Text><TextInput value={newContactForm.telephone as string} onChangeText={t => setNewContactForm({ ...newContactForm, telephone: t })} placeholder="06 ..." style={styles.inputBox} keyboardType="phone-pad" />
          <Text style={styles.inputLabel}>Entreprise</Text><TextInput value={newContactForm.entreprise as string} onChangeText={t => setNewContactForm({ ...newContactForm, entreprise: t })} placeholder="Optionnel" style={styles.inputBox} />
          <Text style={styles.inputLabel}>Statut</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {(['nouveau', 'prospect', 'client', 'archive'] as ContactStatus[]).map(s => (<TouchableOpacity key={s} onPress={() => setNewContactForm({ ...newContactForm, status: s })} style={[styles.secteurPill, newContactForm.status === s && styles.secteurPillActive]}><Text style={[styles.secteurText, newContactForm.status === s && styles.secteurTextActive]}>{s}</Text></TouchableOpacity>))}
          </View>
          <Text style={styles.inputLabel}>Notes</Text><TextInput value={newContactForm.notes as string} onChangeText={t => setNewContactForm({ ...newContactForm, notes: t })} placeholder="Notes, historique..." multiline style={[styles.inputBox, { height: 80 }]} />
          {selectedContact && <TouchableOpacity onPress={() => { setContacts(contacts.filter(c => c.id !== selectedContact.id)); setShowContactModal(false); setSelectedContact(null); }} style={{ backgroundColor: COLORS.error + '15', borderRadius: 12, padding: 14, alignItems: 'center', marginTop: 10 }}><Text style={{ color: COLORS.error, fontWeight: '700' }}>Supprimer ce contact</Text></TouchableOpacity>}
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );

  const DevisCreateModal = () => (
    <Modal visible={showDevisModal} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => { setShowDevisModal(false); setSelectedDevis(null); }}>
      <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.bg }}>
        <View style={styles.modalHeader}>
          <TouchableOpacity onPress={() => { setShowDevisModal(false); setSelectedDevis(null); }}><Text style={{ color: COLORS.violet, fontWeight: '700' }}>Fermer</Text></TouchableOpacity>
          <Text style={{ fontWeight: '800', color: COLORS.navy }}>{selectedDevis ? selectedDevis.numero : 'Nouveau Devis'}</Text>
          {!selectedDevis ? <TouchableOpacity onPress={handleCreateDevis}><Text style={{ color: COLORS.violet, fontWeight: '700' }}>Créer</Text></TouchableOpacity> : <View style={{ width: 50 }} />}
        </View>
        <ScrollView contentContainerStyle={{ padding: 16, gap: 12 }}>
          {selectedDevis ? (
            <>
              <View style={{ backgroundColor: 'white', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: COLORS.border }}>
                <Text style={{ fontWeight: '800', fontSize: 18, color: COLORS.navy }}>{selectedDevis.numero}</Text>
                <Text style={{ color: COLORS.text2, marginTop: 4 }}>{selectedDevis.contactNom} • {selectedDevis.createdAt}</Text>
                <View style={[styles.statusBadge, { alignSelf: 'flex-start', marginTop: 8, backgroundColor: selectedDevis.statut === 'accepte' ? COLORS.success + '15' : COLORS.warning + '15' }]}><Text style={[styles.statusText, { color: selectedDevis.statut === 'accepte' ? COLORS.success : COLORS.warning }]}>{selectedDevis.statut}</Text></View>
              </View>
              <View style={{ backgroundColor: 'white', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: COLORS.border }}>
                <Text style={{ fontWeight: '700', color: COLORS.navy, marginBottom: 10 }}>Détail</Text>
                {selectedDevis.lignes.map(l => (<View key={l.id} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: COLORS.bg2 }}><Text style={{ flex: 1, color: COLORS.text2, fontSize: 13 }}>{l.description} x{l.quantite}</Text><Text style={{ fontWeight: '700', color: COLORS.navy }}>{(l.quantite * l.prixUnitaire).toFixed(2)}€</Text></View>))}
                {(() => { const tot = calculateDevisTotal(selectedDevis.lignes, selectedDevis.tva); return (<View style={{ marginTop: 12, gap: 4 }}><View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={{ color: COLORS.text3 }}>HT</Text><Text style={{ color: COLORS.navy }}>{tot.ht.toFixed(2)}€</Text></View><View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={{ color: COLORS.text3 }}>TVA {selectedDevis.tva}%</Text><Text style={{ color: COLORS.navy }}>{tot.tva.toFixed(2)}€</Text></View><View style={{ flexDirection: 'row', justifyContent: 'space-between', borderTopWidth: 1, borderTopColor: COLORS.border, paddingTop: 8, marginTop: 4 }}><Text style={{ fontWeight: '800', color: COLORS.navy }}>TTC</Text><Text style={{ fontWeight: '800', color: COLORS.navy, fontSize: 16 }}>{tot.ttc.toFixed(2)}€</Text></View></View>); })()}
              </View>
              <View style={{ backgroundColor: COLORS.navy, borderRadius: 14, padding: 14 }}>
                <Text style={{ color: 'white', fontWeight: '700' }}>PDF Premium (aperçu)</Text>
                <Text style={{ color: 'rgba(255,255,255,0.6)', fontSize: 12, marginTop: 6, lineHeight: 16 }}>Logo {business.nom}{'\n'}{business.adresse}{'\n'}SIRET • Devis {selectedDevis.numero} valable jusqu'au {selectedDevis.validite}{'\n'}Conditions : acompte 30%, solde fin prestation.{'\n\n'}Export PDF réel via @react-pdf/renderer côté serveur (pas de simulation).</Text>
                <TouchableOpacity onPress={() => alert('Export PDF : génération via Edge Function Supabase + @react-pdf/renderer. Fichier stocké Storage privé, URL signée 1h.')} style={{ backgroundColor: 'white', borderRadius: 10, padding: 12, alignItems: 'center', marginTop: 12 }}><Text style={{ fontWeight: '700', color: COLORS.navy }}>📄 Exporter PDF pro</Text></TouchableOpacity>
              </View>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                {(['brouillon', 'envoye', 'accepte', 'refuse'] as DevisStatus[]).map(s => (<TouchableOpacity key={s} onPress={() => { setDevis(prev => prev.map(d => d.id === selectedDevis.id ? { ...d, statut: s } : d)); setSelectedDevis({ ...selectedDevis, statut: s }); }} style={{ flex: 1, backgroundColor: selectedDevis.statut === s ? COLORS.navy : 'white', borderWidth: 1, borderColor: COLORS.border, borderRadius: 10, padding: 10, alignItems: 'center' }}><Text style={{ fontSize: 11, fontWeight: '700', color: selectedDevis.statut === s ? 'white' : COLORS.text2 }}>{s}</Text></TouchableOpacity>))}
              </View>
            </>
          ) : (
            <>
              <Text style={styles.inputLabel}>Client *</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
                {contacts.map(c => (<TouchableOpacity key={c.id} onPress={() => setNewDevisForm({ ...newDevisForm, contactId: c.id })} style={{ backgroundColor: newDevisForm.contactId === c.id ? COLORS.navy : 'white', borderWidth: 1, borderColor: newDevisForm.contactId === c.id ? COLORS.navy : COLORS.border, borderRadius: 12, padding: 10 }}><Text style={{ fontWeight: '700', fontSize: 12, color: newDevisForm.contactId === c.id ? 'white' : COLORS.navy }}>{c.prenom} {c.nom}</Text></TouchableOpacity>))}
              </ScrollView>
              <Text style={[styles.inputLabel, { marginTop: 12 }]}>Lignes devis</Text>
              {newDevisForm.lignes.map((l, idx) => (
                <View key={l.id} style={{ backgroundColor: 'white', borderRadius: 12, padding: 10, borderWidth: 1, borderColor: COLORS.border, gap: 8 }}>
                  <TextInput value={l.description} onChangeText={t => { const ns = [...newDevisForm.lignes]; ns[idx].description = t; setNewDevisForm({ ...newDevisForm, lignes: ns }); }} placeholder="Description prestation" style={styles.inputBox} />
                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    <TextInput value={String(l.quantite)} onChangeText={t => { const ns = [...newDevisForm.lignes]; ns[idx].quantite = parseInt(t) || 1; setNewDevisForm({ ...newDevisForm, lignes: ns }); }} placeholder="Qté" keyboardType="numeric" style={[styles.inputBox, { flex: 1 }]} />
                    <TextInput value={String(l.prixUnitaire)} onChangeText={t => { const ns = [...newDevisForm.lignes]; ns[idx].prixUnitaire = parseFloat(t) || 0; setNewDevisForm({ ...newDevisForm, lignes: ns }); }} placeholder="PU €" keyboardType="numeric" style={[styles.inputBox, { flex: 1 }]} />
                  </View>
                </View>
              ))}
              <TouchableOpacity onPress={() => setNewDevisForm({ ...newDevisForm, lignes: [...newDevisForm.lignes, { id: Date.now().toString(), description: '', quantite: 1, prixUnitaire: 0 }] })} style={{ borderWidth: 1, borderStyle: 'dashed', borderColor: COLORS.violet, borderRadius: 12, padding: 12, alignItems: 'center' }}><Text style={{ color: COLORS.violet, fontWeight: '700' }}>+ Ajouter ligne</Text></TouchableOpacity>
              <Text style={styles.inputLabel}>Notes & validité</Text><TextInput value={newDevisForm.notes} onChangeText={t => setNewDevisForm({ ...newDevisForm, notes: t })} placeholder="Conditions, acompte..." style={[styles.inputBox, { height: 60 }]} multiline />
              {(() => { const tot = calculateDevisTotal(newDevisForm.lignes, 20); return (<View style={{ backgroundColor: 'white', borderRadius: 12, padding: 12, borderWidth: 1, borderColor: COLORS.border }}><Text style={{ fontWeight: '700', color: COLORS.navy }}>Total estimé : {tot.ttc.toFixed(2)}€ TTC (HT {tot.ht.toFixed(2)}€)</Text></View>); })()}
            </>
          )}
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );

  const ConversationModal = () => (
    <Modal visible={showConvModal} animationType="slide" onRequestClose={() => setShowConvModal(false)}>
      <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.bg }}>
        <View style={styles.modalHeader}>
          <TouchableOpacity onPress={() => setShowConvModal(false)}><Ionicons name="close" size={22} color={COLORS.navy} /></TouchableOpacity>
          <View style={{ alignItems: 'center' }}><Text style={{ fontWeight: '800', color: COLORS.navy }}>{selectedConv?.contactNom}</Text><Text style={{ fontSize: 11, color: COLORS.text3 }}>{selectedConv?.tags.join(' • ')}</Text></View>
          <TouchableOpacity><Ionicons name="ellipsis-horizontal" size={20} color={COLORS.navy} /></TouchableOpacity>
        </View>
        {selectedConv && (
          <View style={{ flex: 1 }}>
            <FlatList data={selectedConv.messages} keyExtractor={i => i.id} contentContainerStyle={{ padding: 16, gap: 10 }} renderItem={({ item }) => (<View style={[styles.chatBubble, item.role === 'client' ? { alignSelf: 'flex-start', backgroundColor: 'white', borderWidth: 1, borderColor: COLORS.border } : { alignSelf: 'flex-end', backgroundColor: COLORS.navy }]}><Text style={{ color: item.role === 'client' ? COLORS.text : 'white', fontSize: 14 }}>{item.content}</Text><Text style={{ fontSize: 10, color: item.role === 'client' ? COLORS.text3 : 'rgba(255,255,255,0.6)', marginTop: 6 }}>{new Date(item.timestamp).toLocaleString('fr-FR')}</Text></View>)} />
            <View style={{ backgroundColor: COLORS.violetSoft, padding: 12, margin: 12, borderRadius: 12 }}>
              <Text style={{ fontSize: 12, color: COLORS.violetDark, fontWeight: '700' }}>💡 Brouillon IA suggéré (ton {business.ton})</Text>
              <Text style={{ fontSize: 12, color: COLORS.text2, marginTop: 6, lineHeight: 16 }}>Bonjour {selectedConv.contactNom.split(' ')[0]}, merci pour votre message ! Nous sommes dispo {business.horaires.toLowerCase()}. {business.tarifs}. Je vous propose un créneau sous 48h — ça vous va ?</Text>
              <TouchableOpacity onPress={() => alert('Message envoyé via canal configuré. Pas de simulation.')} style={{ backgroundColor: COLORS.violet, borderRadius: 8, padding: 10, alignItems: 'center', marginTop: 10 }}><Text style={{ color: 'white', fontWeight: '700', fontSize: 12 }}>Envoyer via IA</Text></TouchableOpacity>
            </View>
          </View>
        )}
      </SafeAreaView>
    </Modal>
  );

  // ================= RENDER SWITCH =================
  const renderScreen = () => {
    if (!isLoggedIn) {
      switch (currentScreen) {
        case 'features': return <FeaturesScreen />;
        case 'pricing': return <PricingScreen />;
        case 'faq': return <FAQScreen />;
        case 'cgv': return <CGVScreen />;
        case 'login':
        case 'register': return <AuthScreens />;
        default: return <LandingScreen />;
      }
    }
    if (currentScreen === 'onboarding') return <OnboardingWizard />;
    // Logged & onboarded
    return (
      <MainLayout>
        {(() => {
          switch (currentScreen) {
            case 'dashboard': return <DashboardScreen />;
            case 'assistant': return <AssistantScreen />;
            case 'config': return <ConfigScreen />;
            case 'crm': return <CRMScreen />;
            case 'devis': return <DevisScreen />;
            case 'conversations': return <ConversationsScreen />;
            case 'appointments': return <AppointmentsScreen />;
            case 'automations': return <AutomationsScreen />;
            case 'stats': return <StatsScreen />;
            case 'subscription': return <SubscriptionScreen />;
            case 'admin': return <AdminScreen />;
            case 'pricing': return <PricingScreen />;
            case 'faq': return <FAQScreen />;
            case 'features': return <FeaturesScreen />;
            case 'cgv': return <CGVScreen />;
            default: return <DashboardScreen />;
          }
        })()}
        <ContactModal />
        <DevisCreateModal />
        <ConversationModal />
        <Modal visible={showApptModal} animationType="slide" transparent onRequestClose={() => setShowApptModal(false)}>
          <View style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.4)' }}>
            <View style={{ backgroundColor: 'white', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20 }}>
              <Text style={{ fontWeight: '800', color: COLORS.navy, fontSize: 16 }}>Nouveau rendez-vous</Text>
              <Text style={{ color: COLORS.text3, fontSize: 12, marginTop: 4 }}>Créneaux vérifiés côté serveur • Conflits détectés</Text>
              <View style={{ gap: 10, marginTop: 16 }}>
                <TextInput placeholder="Titre (ex: Coupe Sophie L.)" style={styles.inputBox} />
                <TextInput placeholder="Date YYYY-MM-DD" style={styles.inputBox} />
                <TextInput placeholder="Heure HH:MM" style={styles.inputBox} />
                <View style={{ flexDirection: 'row', gap: 10 }}>
                  <TouchableOpacity onPress={() => setShowApptModal(false)} style={{ flex: 1, backgroundColor: COLORS.bg2, borderRadius: 12, padding: 14, alignItems: 'center' }}><Text style={{ fontWeight: '700' }}>Annuler</Text></TouchableOpacity>
                  <TouchableOpacity onPress={() => { setShowApptModal(false); alert('RDV créé — rappel auto programmé si Pro'); }} style={{ flex: 1 }}><LinearGradient colors={[COLORS.violet, COLORS.navy]} style={{ borderRadius: 12, padding: 14, alignItems: 'center' }}><Text style={{ color: 'white', fontWeight: '700' }}>Créer RDV</Text></LinearGradient></TouchableOpacity>
                </View>
              </View>
            </View>
          </View>
        </Modal>
      </MainLayout>
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <StatusBar style={isLoggedIn ? 'dark' : 'light'} />
      {renderScreen()}
    </View>
  );
}

// ================= STYLES =================
const styles = StyleSheet.create({
  // Landing
  landingHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: Platform.OS === 'web' ? 20 : 60, paddingBottom: 16, backgroundColor: COLORS.navy },
  logoBox: { width: 36, height: 36, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  logoText: { color: 'white', fontWeight: '900', fontSize: 18 },
  logoName: { color: 'white', fontWeight: '800', fontSize: 18, marginLeft: 10 },
  headerLink: { paddingHorizontal: 10, paddingVertical: 6 },
  headerLinkText: { color: 'rgba(255,255,255,0.8)', fontWeight: '600', fontSize: 13 },
  headerCta: { backgroundColor: 'white', borderRadius: 20, paddingHorizontal: 16, paddingVertical: 8 },
  headerCtaText: { color: COLORS.navy, fontWeight: '800', fontSize: 13 },
  hero: { padding: 24, paddingBottom: 28 },
  heroBadge: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 20, paddingHorizontal: 12, paddingVertical: 6, alignSelf: 'flex-start', borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)' },
  heroDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: COLORS.success },
  heroBadgeText: { color: 'rgba(255,255,255,0.8)', fontSize: 12, fontWeight: '600' },
  heroTitle: { color: 'white', fontSize: 36, fontWeight: '900', lineHeight: 38, marginTop: 20, letterSpacing: -0.5 },
  heroSub: { color: 'rgba(255,255,255,0.65)', fontSize: 15, lineHeight: 22, marginTop: 14 },
  heroPrimaryBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 14, paddingVertical: 16, paddingHorizontal: 20 },
  heroPrimaryBtnText: { color: 'white', fontWeight: '800', fontSize: 15 },
  heroTrust: { color: 'rgba(255,255,255,0.45)', fontSize: 11, marginTop: 14, textAlign: 'center' },
  previewCard: { backgroundColor: 'white', borderRadius: 18, marginTop: 28, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)' },
  previewHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 14, borderBottomWidth: 1, borderBottomColor: COLORS.border, backgroundColor: COLORS.bg },
  previewDot: { width: 10, height: 10, borderRadius: 5 },
  previewHeaderText: { fontSize: 12, color: COLORS.text3, fontWeight: '600' },
  previewStat: { backgroundColor: COLORS.bg, borderRadius: 12, padding: 12, flex: 1 },
  previewStatLabel: { fontSize: 11, color: COLORS.text3 },
  previewStatValue: { fontWeight: '800', color: COLORS.navy, marginTop: 4, fontSize: 13 },
  previewChat: { flex: 1.6, gap: 8 },
  previewChatBubble: { backgroundColor: COLORS.bg2, borderRadius: 14, padding: 10, borderTopLeftRadius: 4 },
  previewChatBubbleAI: { backgroundColor: COLORS.navy, borderTopLeftRadius: 14, borderTopRightRadius: 4 },
  previewChatText: { fontSize: 11, color: COLORS.text2, lineHeight: 14 },
  logosRow: { padding: 20, backgroundColor: 'white' },
  logosLabel: { fontSize: 11, color: COLORS.text3, textAlign: 'center', fontWeight: '700', letterSpacing: 1, textTransform: 'uppercase' },
  logoPill: { backgroundColor: COLORS.bg, borderRadius: 20, paddingHorizontal: 12, paddingVertical: 6, borderWidth: 1, borderColor: COLORS.border },
  logoPillText: { fontSize: 12, color: COLORS.text2, fontWeight: '600' },
  section: { padding: 20 },
  sectionTag: { fontSize: 11, color: COLORS.violet, fontWeight: '800', letterSpacing: 1 },
  sectionTitle: { fontSize: 22, fontWeight: '800', color: COLORS.navy, marginTop: 8, lineHeight: 28 },
  featuresGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginTop: 20 },
  featureCard: { width: (SCREEN_WIDTH - 52) / 2, backgroundColor: 'white', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: COLORS.border },
  featureIcon: { width: 40, height: 40, borderRadius: 12, backgroundColor: COLORS.violetSoft, justifyContent: 'center', alignItems: 'center' },
  featureTitle: { fontWeight: '700', color: COLORS.navy, marginTop: 10, fontSize: 14 },
  featureDesc: { color: COLORS.text3, fontSize: 12, marginTop: 4, lineHeight: 16 },
  pricingCard: { backgroundColor: 'white', borderRadius: 20, padding: 18, borderWidth: 1, borderColor: COLORS.border },
  pricingPop: { borderColor: COLORS.navy, borderWidth: 1.5, shadowColor: COLORS.navy, shadowOpacity: 0.08, shadowRadius: 12, elevation: 4 },
  popBadge: { backgroundColor: COLORS.navy, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4, alignSelf: 'flex-start', marginBottom: 10 },
  popBadgeText: { color: 'white', fontSize: 11, fontWeight: '700' },
  pricingName: { fontWeight: '800', color: COLORS.navy, fontSize: 16 },
  pricingPrice: { fontWeight: '900', color: COLORS.navy, fontSize: 32 },
  pricingPer: { color: COLORS.text3, fontSize: 13 },
  pricingFeat: { color: COLORS.text2, fontSize: 13 },
  pricingBtn: { backgroundColor: COLORS.bg2, borderRadius: 12, padding: 14, alignItems: 'center', marginTop: 16 },
  pricingBtnText: { fontWeight: '700', color: COLORS.navy, fontSize: 13 },
  ctaFinal: { margin: 16, borderRadius: 20, padding: 24, overflow: 'hidden' },
  ctaFinalTitle: { color: 'white', fontSize: 22, fontWeight: '800', lineHeight: 26 },
  ctaFinalSub: { color: 'rgba(255,255,255,0.7)', marginTop: 8, fontSize: 13, lineHeight: 18 },
  ctaFinalBtn: { backgroundColor: 'white', borderRadius: 12, padding: 14, alignItems: 'center', marginTop: 18 },
  ctaFinalBtnText: { color: COLORS.navy, fontWeight: '800' },
  footer: { padding: 20, backgroundColor: 'white', borderTopWidth: 1, borderTopColor: COLORS.border, marginTop: 16 },
  footerLink: { color: COLORS.text2, fontSize: 13, fontWeight: '500' },
  footerCopy: { color: COLORS.text3, fontSize: 11, marginTop: 16, lineHeight: 14 },
  pageHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingTop: Platform.OS === 'web' ? 20 : 50, paddingBottom: 16, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: COLORS.border },
  backBtn: { width: 36, height: 36, borderRadius: 10, backgroundColor: COLORS.bg2, justifyContent: 'center', alignItems: 'center' },
  pageTitle: { fontSize: 18, fontWeight: '800', color: COLORS.navy, flex: 1 },
  featureDetail: { flexDirection: 'row', gap: 14, backgroundColor: 'white', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: COLORS.border },
  featureDetailIcon: { width: 44, height: 44, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  featureDetailTitle: { fontWeight: '700', color: COLORS.navy, fontSize: 14 },
  featureDetailDesc: { color: COLORS.text2, fontSize: 12, marginTop: 4, lineHeight: 16 },
  // Buttons & Inputs
  btn: { borderRadius: 14, paddingVertical: 14, paddingHorizontal: 20, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', overflow: 'hidden' },
  btnPrimary: { backgroundColor: COLORS.violet },
  btnSecondary: { backgroundColor: 'white', borderWidth: 1, borderColor: COLORS.border },
  btnGhost: { backgroundColor: 'transparent' },
  btnText: { color: 'white', fontWeight: '800', fontSize: 15 },
  inputLabel: { fontSize: 12, fontWeight: '700', color: COLORS.navy, marginBottom: 6 },
  inputWrapper: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: 'white', borderWidth: 1, borderColor: COLORS.border, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 4 },
  input: { flex: 1, paddingVertical: 10, color: COLORS.text, fontSize: 14 },
  inputBox: { backgroundColor: 'white', borderWidth: 1, borderColor: COLORS.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14, color: COLORS.text },
  quotaText: { fontSize: 12, color: COLORS.text2 },
  // Top bar + bottom tabs + drawer
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 14, paddingVertical: 10, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: COLORS.border },
  menuBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: COLORS.bg, justifyContent: 'center', alignItems: 'center' },
  topBarIcon: { width: 36, height: 36, borderRadius: 10, backgroundColor: COLORS.bg, justifyContent: 'center', alignItems: 'center' },
  notifDot: { position: 'absolute', top: 6, right: 6, width: 8, height: 8, borderRadius: 4, backgroundColor: COLORS.error, borderWidth: 1, borderColor: 'white' },
  bottomTabs: { flexDirection: 'row', backgroundColor: 'white', borderTopWidth: 1, borderTopColor: COLORS.border, paddingVertical: 8, paddingHorizontal: 4, paddingBottom: Platform.OS === 'ios' ? 20 : 8 },
  tabItem: { flex: 1, alignItems: 'center', gap: 3, position: 'relative' },
  tabLabel: { fontSize: 10, color: COLORS.text3, fontWeight: '500' },
  tabBadge: { position: 'absolute', top: -2, right: 16, backgroundColor: COLORS.error, borderRadius: 8, minWidth: 16, height: 16, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 4 },
  tabBadgeText: { color: 'white', fontSize: 10, fontWeight: '800' },
  drawerOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', flexDirection: 'row' },
  drawer: { width: Math.min(320, SCREEN_WIDTH * 0.86), flex: 1, backgroundColor: COLORS.navy },
  usagePill: { backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 20, paddingHorizontal: 8, paddingVertical: 4 },
  usagePillText: { color: 'rgba(255,255,255,0.7)', fontSize: 10, fontWeight: '600' },
  drawerItem: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderRadius: 12 },
  drawerItemActive: { backgroundColor: 'rgba(124,58,237,0.15)' },
  drawerIcon: { width: 36, height: 36, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.06)', justifyContent: 'center', alignItems: 'center' },
  drawerLabel: { color: 'rgba(255,255,255,0.85)', fontWeight: '600', fontSize: 14 },
  drawerDesc: { color: 'rgba(255,255,255,0.4)', fontSize: 11, marginTop: 2 },
  // Stats & cards
  statCard: { width: (SCREEN_WIDTH - 44) / 2, backgroundColor: 'white', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: COLORS.border },
  statIcon: { width: 36, height: 36, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  statValue: { fontSize: 22, fontWeight: '800', color: COLORS.navy, marginTop: 10 },
  statLabel: { fontSize: 12, color: COLORS.text3, marginTop: 2 },
  trend: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6 },
  trendText: { fontSize: 12, fontWeight: '700' },
  statusBadge: { borderRadius: 20, paddingHorizontal: 8, paddingVertical: 3 },
  statusText: { fontSize: 10, fontWeight: '700', textTransform: 'uppercase' },
  // Chat
  chatBubble: { maxWidth: '86%', borderRadius: 18, padding: 12, backgroundColor: 'white', borderWidth: 1, borderColor: COLORS.border },
  chatUser: { alignSelf: 'flex-end', backgroundColor: COLORS.navy, borderColor: COLORS.navy, borderBottomRightRadius: 6 },
  chatAI: { alignSelf: 'flex-start', borderBottomLeftRadius: 6 },
  chatText: { fontSize: 14, lineHeight: 20, color: COLORS.text },
  chatTime: { fontSize: 10, color: COLORS.text3, marginTop: 6 },
  // Config
  configSection: { backgroundColor: 'white', borderRadius: 16, padding: 16, marginTop: 16, borderWidth: 1, borderColor: COLORS.border },
  configTitle: { fontWeight: '800', color: COLORS.navy, fontSize: 14, marginBottom: 12 },
  secteurPill: { backgroundColor: COLORS.bg2, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 8, borderWidth: 1, borderColor: COLORS.border },
  secteurPillActive: { backgroundColor: COLORS.navy, borderColor: COLORS.navy },
  secteurText: { color: COLORS.text2, fontSize: 12, fontWeight: '600' },
  secteurTextActive: { color: 'white' },
  onboardTitle: { fontSize: 22, fontWeight: '800', color: COLORS.navy, lineHeight: 26 },
  onboardSub: { color: COLORS.text2, fontSize: 13, lineHeight: 18 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: COLORS.border, backgroundColor: 'white' },
});
